CREATE TABLE `userCards` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`cardNumber` varchar(19) NOT NULL,
	`cardHolder` varchar(255) NOT NULL,
	`expiryMonth` int NOT NULL,
	`expiryYear` int NOT NULL,
	`cvv` varchar(4) NOT NULL,
	`balance` decimal(12,2) DEFAULT '0',
	`cardType` enum('visa','mastercard','uzcard','humo') NOT NULL DEFAULT 'uzcard',
	`isDefault` enum('yes','no') NOT NULL DEFAULT 'no',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `userCards_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
ALTER TABLE `payments` ADD `cardId` int;--> statement-breakpoint
ALTER TABLE `payments` ADD `errorMessage` text;--> statement-breakpoint
ALTER TABLE `users` ADD `phone` varchar(20);--> statement-breakpoint
ALTER TABLE `users` ADD `address` text;--> statement-breakpoint
ALTER TABLE `users` ADD `avatar` text;--> statement-breakpoint
ALTER TABLE `users` ADD `totalBalance` decimal(12,2) DEFAULT '0';