CREATE TABLE `clickCreditOffers` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`creditAmount` decimal(12,2) NOT NULL,
	`maxAmount` decimal(12,2) NOT NULL,
	`interestRate` decimal(5,2) NOT NULL,
	`terms` int NOT NULL,
	`status` enum('active','used','expired') NOT NULL DEFAULT 'active',
	`expiryDate` timestamp NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `clickCreditOffers_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `clickEasyPayments` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`cardId` int NOT NULL,
	`paymentAmount` decimal(12,2) NOT NULL,
	`installments` int NOT NULL,
	`monthlyAmount` decimal(12,2) NOT NULL,
	`interestRate` decimal(5,2) DEFAULT '0',
	`status` enum('active','completed','cancelled') NOT NULL DEFAULT 'active',
	`paidInstallments` int DEFAULT 0,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `clickEasyPayments_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `clickLoanPayments` (
	`id` int AUTO_INCREMENT NOT NULL,
	`loanId` int NOT NULL,
	`userId` int NOT NULL,
	`paymentAmount` decimal(12,2) NOT NULL,
	`paymentDate` timestamp NOT NULL DEFAULT (now()),
	`status` enum('completed','pending','failed') NOT NULL DEFAULT 'pending',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `clickLoanPayments_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `clickLoans` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`cardId` int NOT NULL,
	`loanAmount` decimal(12,2) NOT NULL,
	`monthlyPayment` decimal(12,2) NOT NULL,
	`months` int NOT NULL,
	`interestRate` decimal(5,2) DEFAULT '0',
	`status` enum('active','completed','rejected','pending') NOT NULL DEFAULT 'pending',
	`paidAmount` decimal(12,2) DEFAULT '0',
	`remainingAmount` decimal(12,2) NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `clickLoans_id` PRIMARY KEY(`id`)
);
