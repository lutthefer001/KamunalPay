import { int, mysqlEnum, mysqlTable, text, timestamp, varchar, decimal } from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 * Extend this file with additional tables as your product grows.
 * Columns use camelCase to match both database fields and generated types.
 */
export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  phone: varchar("phone", { length: 20 }),
  address: text("address"),
  avatar: text("avatar"),
  totalBalance: decimal("totalBalance", { precision: 12, scale: 2 }).default("0"),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

/**
 * User Cards table: Saved payment cards
 */
export const userCards = mysqlTable("userCards", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  cardNumber: varchar("cardNumber", { length: 19 }).notNull(),
  cardHolder: varchar("cardHolder", { length: 255 }).notNull(),
  expiryMonth: int("expiryMonth").notNull(),
  expiryYear: int("expiryYear").notNull(),
  cvv: varchar("cvv", { length: 4 }).notNull(),
  balance: decimal("balance", { precision: 12, scale: 2 }).default("0"),
  cardType: mysqlEnum("cardType", ["visa", "mastercard", "uzcard", "humo"]).default("uzcard").notNull(),
  isDefault: mysqlEnum("isDefault", ["yes", "no"]).default("no").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type UserCard = typeof userCards.$inferSelect;
export type InsertUserCard = typeof userCards.$inferInsert;

/**
 * Providers table: All service providers (Utilities, Mobile, Internet, TV, etc.)
 */
export const providers = mysqlTable("providers", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  serviceCategory: mysqlEnum("serviceCategory", [
    "utilities",
    "mobile",
    "internet",
    "tv",
    "landline",
    "hosting",
    "transfer",
    "other"
  ]).default("utilities").notNull(),
  account_check_api: text("account_check_api"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Provider = typeof providers.$inferSelect;
export type InsertProvider = typeof providers.$inferInsert;

/**
 * Payments table: Payment history
 */
export const payments = mysqlTable("payments", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  providerId: int("providerId").notNull(),
  cardId: int("cardId"),
  accountNumber: varchar("accountNumber", { length: 255 }).notNull(),
  amount: int("amount").notNull(),
  status: mysqlEnum("status", ["pending", "completed", "failed"]).default("pending").notNull(),
  receiptNumber: varchar("receiptNumber", { length: 255 }),
  errorMessage: text("errorMessage"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Payment = typeof payments.$inferSelect;
export type InsertPayment = typeof payments.$inferInsert;

/**
 * SavedAccounts table: User's saved account numbers for quick access
 */
export const savedAccounts = mysqlTable("savedAccounts", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  providerId: int("providerId").notNull(),
  accountNumber: varchar("accountNumber", { length: 255 }).notNull(),
  accountName: varchar("accountName", { length: 255 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type SavedAccount = typeof savedAccounts.$inferSelect;
export type InsertSavedAccount = typeof savedAccounts.$inferInsert;

/**
 * USSD Requests table: Track USSD queries
 */
export const ussdRequests = mysqlTable("ussdRequests", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  requestType: mysqlEnum("requestType", [
    "login",
    "register",
    "balance_check"
  ]).notNull(),
  phoneNumber: varchar("phoneNumber", { length: 20 }),
  status: mysqlEnum("status", ["pending", "completed", "failed"]).default("pending").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type UssdRequest = typeof ussdRequests.$inferSelect;
export type InsertUssdRequest = typeof ussdRequests.$inferInsert;

/**
 * Click Loans table: User loans
 */
export const clickLoans = mysqlTable("clickLoans", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  cardId: int("cardId").notNull(),
  loanAmount: decimal("loanAmount", { precision: 12, scale: 2 }).notNull(),
  monthlyPayment: decimal("monthlyPayment", { precision: 12, scale: 2 }).notNull(),
  months: int("months").notNull(),
  interestRate: decimal("interestRate", { precision: 5, scale: 2 }).default("0"),
  status: mysqlEnum("status", ["active", "completed", "rejected", "pending"]).default("pending").notNull(),
  paidAmount: decimal("paidAmount", { precision: 12, scale: 2 }).default("0"),
  remainingAmount: decimal("remainingAmount", { precision: 12, scale: 2 }).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type ClickLoan = typeof clickLoans.$inferSelect;
export type InsertClickLoan = typeof clickLoans.$inferInsert;

/**
 * Click Credit Offers table: Available credit offers
 */
export const clickCreditOffers = mysqlTable("clickCreditOffers", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  creditAmount: decimal("creditAmount", { precision: 12, scale: 2 }).notNull(),
  maxAmount: decimal("maxAmount", { precision: 12, scale: 2 }).notNull(),
  interestRate: decimal("interestRate", { precision: 5, scale: 2 }).notNull(),
  terms: int("terms").notNull(),
  status: mysqlEnum("status", ["active", "used", "expired"]).default("active").notNull(),
  expiryDate: timestamp("expiryDate").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type ClickCreditOffer = typeof clickCreditOffers.$inferSelect;
export type InsertClickCreditOffer = typeof clickCreditOffers.$inferInsert;

/**
 * Click Easy Payments table: Easy payment plans
 */
export const clickEasyPayments = mysqlTable("clickEasyPayments", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  cardId: int("cardId").notNull(),
  paymentAmount: decimal("paymentAmount", { precision: 12, scale: 2 }).notNull(),
  installments: int("installments").notNull(),
  monthlyAmount: decimal("monthlyAmount", { precision: 12, scale: 2 }).notNull(),
  interestRate: decimal("interestRate", { precision: 5, scale: 2 }).default("0"),
  status: mysqlEnum("status", ["active", "completed", "cancelled"]).default("active").notNull(),
  paidInstallments: int("paidInstallments").default(0),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type ClickEasyPayment = typeof clickEasyPayments.$inferSelect;
export type InsertClickEasyPayment = typeof clickEasyPayments.$inferInsert;

/**
 * Click Loan Payments table: Track loan payments
 */
export const clickLoanPayments = mysqlTable("clickLoanPayments", {
  id: int("id").autoincrement().primaryKey(),
  loanId: int("loanId").notNull(),
  userId: int("userId").notNull(),
  paymentAmount: decimal("paymentAmount", { precision: 12, scale: 2 }).notNull(),
  paymentDate: timestamp("paymentDate").defaultNow().notNull(),
  status: mysqlEnum("status", ["completed", "pending", "failed"]).default("pending").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type ClickLoanPayment = typeof clickLoanPayments.$inferSelect;
export type InsertClickLoanPayment = typeof clickLoanPayments.$inferInsert;
