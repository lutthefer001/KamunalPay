CREATE TABLE `ussdRequests` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`requestType` enum('login','register','balance_check') NOT NULL,
	`phoneNumber` varchar(20),
	`status` enum('pending','completed','failed') NOT NULL DEFAULT 'pending',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `ussdRequests_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
ALTER TABLE `providers` ADD `serviceCategory` enum('utilities','mobile','internet','tv','landline','hosting','transfer','other') DEFAULT 'utilities' NOT NULL;