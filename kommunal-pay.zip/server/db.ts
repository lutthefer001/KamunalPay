import { eq, and } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { InsertUser, users, userCards, InsertUserCard, UserCard } from "../drizzle/schema";
import { ENV } from './_core/env';

let _db: ReturnType<typeof drizzle> | null = null;

// Lazily create the drizzle instance so local tooling can run without a DB.
export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod", "phone", "address", "avatar"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = 'admin';
      updateSet.role = 'admin';
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });

    // Get the user to check if this is a new user
    const userRecord = await db.select().from(users).where(eq(users.openId, user.openId)).limit(1);
    if (userRecord.length > 0) {
      const userId = userRecord[0].id;
      // Create default card with 10 million balance for new users
      const existingCards = await db
        .select()
        .from(userCards)
        .where(eq(userCards.userId, userId))
        .limit(1);

      if (existingCards.length === 0) {
        await db.insert(userCards).values({
          userId: userId,
          cardNumber: "9860000000000001",
          cardHolder: "DEFAULT CARD",
          expiryMonth: 12,
          expiryYear: new Date().getFullYear() + 5,
          cvv: "000",
          cardType: "uzcard",
          balance: "10000000",
          isDefault: "yes",
        });
      }
    }
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);

  return result.length > 0 ? result[0] : undefined;
}

export async function getUserById(userId: number) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.id, userId)).limit(1);

  return result.length > 0 ? result[0] : undefined;
}

export async function updateUserProfile(userId: number, data: Partial<InsertUser>) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot update user: database not available");
    return undefined;
  }

  await db.update(users).set(data).where(eq(users.id, userId));
  return getUserById(userId);
}

// Card management queries
export async function getUserCards(userId: number) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get cards: database not available");
    return [];
  }

  return await db.select().from(userCards).where(eq(userCards.userId, userId));
}

export async function createUserCard(card: InsertUserCard) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot create card: database not available");
    return undefined;
  }

  const result = await db.insert(userCards).values(card);
  return result;
}

export async function updateUserCard(cardId: number, data: Partial<UserCard>) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot update card: database not available");
    return undefined;
  }

  await db.update(userCards).set(data).where(eq(userCards.id, cardId));
  
  const result = await db.select().from(userCards).where(eq(userCards.id, cardId)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function deleteUserCard(cardId: number) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot delete card: database not available");
    return false;
  }

  await db.delete(userCards).where(eq(userCards.id, cardId));
  return true;
}

export async function getDefaultCard(userId: number) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get default card: database not available");
    return undefined;
  }

  const result = await db
    .select()
    .from(userCards)
    .where(and(eq(userCards.userId, userId), eq(userCards.isDefault, "yes")))
    .limit(1);

  return result.length > 0 ? result[0] : undefined;
}
