import { protectedProcedure, router } from "./_core/trpc";
import { z } from "zod";
import { clickLoans, clickCreditOffers, clickEasyPayments, clickLoanPayments } from "../drizzle/schema";
import { eq, and, desc } from "drizzle-orm";

export const clickRouter = router({
  // Loans
  loans: router({
    list: protectedProcedure.query(async ({ ctx }) => {
      if (!ctx.db) throw new Error("Database not available");
      return await ctx.db
        .select()
        .from(clickLoans)
        .where(eq(clickLoans.userId, ctx.user!.id))
        .orderBy(desc(clickLoans.createdAt))
        .execute();
    }),
    create: protectedProcedure
      .input(
        z.object({
          cardId: z.number(),
          loanAmount: z.string(),
          months: z.number().min(1).max(60),
          interestRate: z.string().default("0"),
        })
      )
      .mutation(async ({ ctx, input }) => {
        if (!ctx.db) throw new Error("Database not available");

        const loanAmount = parseFloat(input.loanAmount);
        if (loanAmount <= 0) {
          throw new Error("Qarz summasi 0 dan katta bo'lishi kerak");
        }

        const interestRate = parseFloat(input.interestRate);
        const totalAmount = loanAmount * (1 + interestRate / 100);
        const monthlyPayment = totalAmount / input.months;
        const remainingAmount = totalAmount;

        const result = await ctx.db.insert(clickLoans).values({
          userId: ctx.user!.id,
          cardId: input.cardId,
          loanAmount: loanAmount.toString(),
          monthlyPayment: monthlyPayment.toString(),
          months: input.months,
          interestRate: interestRate.toString(),
          status: "pending",
          remainingAmount: remainingAmount.toString(),
        });

        return result;
      }),
    pay: protectedProcedure
      .input(
        z.object({
          loanId: z.number(),
          paymentAmount: z.string(),
        })
      )
      .mutation(async ({ ctx, input }) => {
        if (!ctx.db) throw new Error("Database not available");

        const loan = await ctx.db
          .select()
          .from(clickLoans)
          .where(and(eq(clickLoans.id, input.loanId), eq(clickLoans.userId, ctx.user!.id)))
          .limit(1);

        if (loan.length === 0) {
          throw new Error("Qarz topilmadi");
        }

        const paymentAmount = parseFloat(input.paymentAmount);
        const remainingAmount = parseFloat(loan[0].remainingAmount || "0");

        if (paymentAmount > remainingAmount) {
          throw new Error("To'lov summasi qolgan qarzdan ko'p");
        }

        // Create payment record
        await ctx.db.insert(clickLoanPayments).values({
          loanId: input.loanId,
          userId: ctx.user!.id,
          paymentAmount: paymentAmount.toString(),
          status: "completed",
        });

        // Update loan
        const newRemaining = remainingAmount - paymentAmount;
        const paidAmount = parseFloat(loan[0].paidAmount || "0") + paymentAmount;

        const status = newRemaining <= 0 ? "completed" : "active";

        await ctx.db
          .update(clickLoans)
          .set({
            remainingAmount: Math.max(0, newRemaining).toString(),
            paidAmount: paidAmount.toString(),
            status,
          })
          .where(eq(clickLoans.id, input.loanId));

        return { success: true, remainingAmount: Math.max(0, newRemaining) };
      }),
  }),

  // Credit Offers
  creditOffers: router({
    list: protectedProcedure.query(async ({ ctx }) => {
      if (!ctx.db) throw new Error("Database not available");
      return await ctx.db
        .select()
        .from(clickCreditOffers)
        .where(eq(clickCreditOffers.userId, ctx.user!.id))
        .orderBy(desc(clickCreditOffers.createdAt))
        .execute();
    }),
    create: protectedProcedure
      .input(
        z.object({
          creditAmount: z.string(),
          maxAmount: z.string(),
          interestRate: z.string(),
          terms: z.number(),
        })
      )
      .mutation(async ({ ctx, input }) => {
        if (!ctx.db) throw new Error("Database not available");

        const creditAmount = parseFloat(input.creditAmount);
        const maxAmount = parseFloat(input.maxAmount);

        if (creditAmount <= 0 || maxAmount <= 0) {
          throw new Error("Kredit summasi 0 dan katta bo'lishi kerak");
        }

        if (creditAmount > maxAmount) {
          throw new Error("Kredit summasi maksimal summadan ko'p bo'lishi mumkin emas");
        }

        const expiryDate = new Date();
        expiryDate.setDate(expiryDate.getDate() + 365); // 1 year validity

        const result = await ctx.db.insert(clickCreditOffers).values({
          userId: ctx.user!.id,
          creditAmount: creditAmount.toString(),
          maxAmount: maxAmount.toString(),
          interestRate: input.interestRate,
          terms: input.terms,
          status: "active",
          expiryDate,
        });

        return result;
      }),
  }),

  // Easy Payments
  easyPayments: router({
    list: protectedProcedure.query(async ({ ctx }) => {
      if (!ctx.db) throw new Error("Database not available");
      return await ctx.db
        .select()
        .from(clickEasyPayments)
        .where(eq(clickEasyPayments.userId, ctx.user!.id))
        .orderBy(desc(clickEasyPayments.createdAt))
        .execute();
    }),
    create: protectedProcedure
      .input(
        z.object({
          cardId: z.number(),
          paymentAmount: z.string(),
          installments: z.number().min(2).max(12),
          interestRate: z.string().default("0"),
        })
      )
      .mutation(async ({ ctx, input }) => {
        if (!ctx.db) throw new Error("Database not available");

        const paymentAmount = parseFloat(input.paymentAmount);
        if (paymentAmount <= 0) {
          throw new Error("To'lov summasi 0 dan katta bo'lishi kerak");
        }

        const interestRate = parseFloat(input.interestRate);
        const totalAmount = paymentAmount * (1 + interestRate / 100);
        const monthlyAmount = totalAmount / input.installments;

        const result = await ctx.db.insert(clickEasyPayments).values({
          userId: ctx.user!.id,
          cardId: input.cardId,
          paymentAmount: paymentAmount.toString(),
          installments: input.installments,
          monthlyAmount: monthlyAmount.toString(),
          interestRate: interestRate.toString(),
          status: "active",
          paidInstallments: 0,
        });

        return result;
      }),
    payInstallment: protectedProcedure
      .input(
        z.object({
          easyPaymentId: z.number(),
        })
      )
      .mutation(async ({ ctx, input }) => {
        if (!ctx.db) throw new Error("Database not available");

        const payment = await ctx.db
          .select()
          .from(clickEasyPayments)
          .where(
            and(
              eq(clickEasyPayments.id, input.easyPaymentId),
              eq(clickEasyPayments.userId, ctx.user!.id)
            )
          )
          .limit(1);

        if (payment.length === 0) {
          throw new Error("To'lov rejasi topilmadi");
        }

        const paidInstallments = (payment[0].paidInstallments || 0) + 1;
        const status = paidInstallments >= payment[0].installments ? "completed" : "active";

        await ctx.db
          .update(clickEasyPayments)
          .set({
            paidInstallments,
            status,
          })
          .where(eq(clickEasyPayments.id, input.easyPaymentId));

        return { success: true, paidInstallments, totalInstallments: payment[0].installments };
      }),
  }),

  // Loan Payments History
  loanPayments: router({
    list: protectedProcedure
      .input(
        z.object({
          loanId: z.number().optional(),
        })
      )
      .query(async ({ ctx, input }) => {
        if (!ctx.db) throw new Error("Database not available");

        let query = ctx.db
          .select()
          .from(clickLoanPayments)
          .where(eq(clickLoanPayments.userId, ctx.user!.id));

        if (input.loanId) {
          query = ctx.db
            .select()
            .from(clickLoanPayments)
            .where(
              and(
                eq(clickLoanPayments.userId, ctx.user!.id),
                eq(clickLoanPayments.loanId, input.loanId)
              )
            );
        }

        return await query.orderBy(desc(clickLoanPayments.createdAt)).execute();
      }),
  }),

  // Dashboard Statistics
  stats: router({
    overview: protectedProcedure.query(async ({ ctx }) => {
      if (!ctx.db) throw new Error("Database not available");

      const loans = await ctx.db
        .select()
        .from(clickLoans)
        .where(eq(clickLoans.userId, ctx.user!.id))
        .execute();

      const creditOffers = await ctx.db
        .select()
        .from(clickCreditOffers)
        .where(eq(clickCreditOffers.userId, ctx.user!.id))
        .execute();

      const easyPayments = await ctx.db
        .select()
        .from(clickEasyPayments)
        .where(eq(clickEasyPayments.userId, ctx.user!.id))
        .execute();

      const totalLoanAmount = loans.reduce((sum, loan) => sum + parseFloat(loan.loanAmount || "0"), 0);
      const totalRemainingAmount = loans.reduce((sum, loan) => sum + parseFloat(loan.remainingAmount || "0"), 0);
      const totalCreditAvailable = creditOffers.reduce((sum, offer) => sum + parseFloat(offer.creditAmount || "0"), 0);
      const activeEasyPayments = easyPayments.filter((p) => p.status === "active").length;

      return {
        totalLoans: loans.length,
        activeLoans: loans.filter((l) => l.status === "active").length,
        totalLoanAmount,
        totalRemainingAmount,
        creditOffers: creditOffers.length,
        totalCreditAvailable,
        easyPayments: easyPayments.length,
        activeEasyPayments,
      };
    }),
  }),
});
