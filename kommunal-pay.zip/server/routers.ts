import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, protectedProcedure, router } from "./_core/trpc";
import { payments, savedAccounts, providers, ussdRequests, userCards } from "../drizzle/schema";
import { and, eq, desc } from "drizzle-orm";
import { z } from "zod";
import { getUserById, updateUserProfile, getUserCards, createUserCard, updateUserCard, deleteUserCard, getDefaultCard } from "./db";
import { clickRouter } from "./click-router";

// Card validation helper
function validateCardNumber(cardNumber: string): boolean {
  const cleaned = cardNumber.replace(/\s/g, "");
  if (!/^\d{16}$/.test(cleaned)) return false;
  
  // Check if card starts with 9860 (Uzbek card)
  if (!cleaned.startsWith("9860")) {
    return false;
  }
  
  // For test cards, skip Luhn validation
  // Real implementation would validate with Luhn algorithm
  return true;
}

function validateExpiry(month: number, year: number): boolean {
  if (month < 1 || month > 12) return false;
  const now = new Date();
  const currentYear = now.getFullYear();
  const currentMonth = now.getMonth() + 1;
  
  if (year < currentYear) return false;
  if (year === currentYear && month < currentMonth) return false;
  
  return true;
}

function validateCVV(cvv: string): boolean {
  return /^\d{3,4}$/.test(cvv);
}

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  // User Profile Management
  profile: router({
    get: protectedProcedure.query(async ({ ctx }) => {
      const user = await getUserById(ctx.user!.id);
      return user;
    }),
    update: protectedProcedure
      .input(
        z.object({
          name: z.string().optional(),
          phone: z.string().optional(),
          address: z.string().optional(),
          avatar: z.string().optional(),
        })
      )
      .mutation(async ({ ctx, input }) => {
        return await updateUserProfile(ctx.user!.id, input);
      }),
  }),

  // User Cards Management
  cards: router({
    list: protectedProcedure.query(async ({ ctx }) => {
      return await getUserCards(ctx.user!.id);
    }),
    create: protectedProcedure
      .input(
        z.object({
          cardNumber: z.string(),
          cardHolder: z.string(),
          expiryMonth: z.number(),
          expiryYear: z.number(),
          cvv: z.string(),
          cardType: z.enum(["visa", "mastercard", "uzcard", "humo"]).default("uzcard"),
          balance: z.string().default("0"),
        })
      )
      .mutation(async ({ ctx, input }) => {
        // Validate card
        if (!validateCardNumber(input.cardNumber)) {
          throw new Error("Karta raqami noto'g'ri");
        }
        if (!validateExpiry(input.expiryMonth, input.expiryYear)) {
          throw new Error("Karta muddati tugagan");
        }
        if (!validateCVV(input.cvv)) {
          throw new Error("CVV noto'g'ri");
        }

        // Check if card already exists
        if (!ctx.db) throw new Error("Database not available");
        const existing = await ctx.db
          .select()
          .from(userCards)
          .where(
            and(
              eq(userCards.userId, ctx.user!.id),
              eq(userCards.cardNumber, input.cardNumber)
            )
          )
          .limit(1);

        if (existing.length > 0) {
          throw new Error("Bu karta allaqachon saqlangan");
        }

        return await createUserCard({
          userId: ctx.user!.id,
          cardNumber: input.cardNumber,
          cardHolder: input.cardHolder,
          expiryMonth: input.expiryMonth,
          expiryYear: input.expiryYear,
          cvv: input.cvv,
          cardType: input.cardType,
          balance: input.balance,
          isDefault: "no",
        });
      }),
    update: protectedProcedure
      .input(
        z.object({
          cardId: z.number(),
          balance: z.string().optional(),
          isDefault: z.enum(["yes", "no"]).optional(),
        })
      )
      .mutation(async ({ ctx, input }) => {
        // Verify card belongs to user
        if (!ctx.db) throw new Error("Database not available");
        const card = await ctx.db
          .select()
          .from(userCards)
          .where(
            and(
              eq(userCards.id, input.cardId),
              eq(userCards.userId, ctx.user!.id)
            )
          )
          .limit(1);

        if (card.length === 0) {
          throw new Error("Karta topilmadi");
        }

        // If setting as default, unset others
        if (input.isDefault === "yes") {
          await ctx.db
            .update(userCards)
            .set({ isDefault: "no" })
            .where(eq(userCards.userId, ctx.user!.id));
        }

        return await updateUserCard(input.cardId, {
          balance: input.balance,
          isDefault: input.isDefault,
        });
      }),
    delete: protectedProcedure
      .input(z.object({ cardId: z.number() }))
      .mutation(async ({ ctx, input }) => {
        // Verify card belongs to user
        if (!ctx.db) throw new Error("Database not available");
        const card = await ctx.db
          .select()
          .from(userCards)
          .where(
            and(
              eq(userCards.id, input.cardId),
              eq(userCards.userId, ctx.user!.id)
            )
          )
          .limit(1);

        if (card.length === 0) {
          throw new Error("Karta topilmadi");
        }

        return await deleteUserCard(input.cardId);
      }),
    getDefault: protectedProcedure.query(async ({ ctx }) => {
      return await getDefaultCard(ctx.user!.id);
    }),
  }),

  providers: router({
    list: publicProcedure.query(({ ctx }) => {
      if (!ctx.db) throw new Error("Database not available");
      return ctx.db.select().from(providers).execute();
    }),
  }),

  payments: router({
    list: protectedProcedure.query(({ ctx }) => {
      if (!ctx.db) throw new Error("Database not available");
      return ctx.db
        .select()
        .from(payments)
        .where(eq(payments.userId, ctx.user!.id))
        .orderBy(desc(payments.createdAt))
        .execute();
    }),
    create: protectedProcedure
      .input(
        z.object({
          providerId: z.number(),
          accountNumber: z.string(),
          amount: z.number(),
          cardId: z.number().optional(),
        })
      )
      .mutation(async ({ ctx, input }) => {
        if (!ctx.db) throw new Error("Database not available");

        // Validate account number
        if (!input.accountNumber || input.accountNumber.trim().length === 0) {
          throw new Error("Hisob raqami bo'sh bo'lishi mumkin emas");
        }

        // Validate amount
        if (input.amount <= 0) {
          throw new Error("To'lov summasi 0 dan katta bo'lishi kerak");
        }

        // Check card balance if cardId provided
        if (input.cardId) {
          const card = await ctx.db
            .select()
            .from(userCards)
            .where(
              and(
                eq(userCards.id, input.cardId),
                eq(userCards.userId, ctx.user!.id)
              )
            )
            .limit(1);

          if (card.length === 0) {
            throw new Error("Karta topilmadi");
          }

          const cardBalance = parseFloat(card[0].balance || "0");
          if (cardBalance < input.amount / 100) {
            throw new Error(`Kartada yetarli pul yo'q. Balans: ${cardBalance} so'm`);
          }
        }

        const result = await ctx.db.insert(payments).values({
          userId: ctx.user!.id,
          providerId: input.providerId,
          accountNumber: input.accountNumber,
          amount: input.amount,
          cardId: input.cardId,
          status: "completed",
          receiptNumber: `RCP-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
        });
        return result;
      }),
  }),

  savedAccounts: router({
    list: protectedProcedure.query(({ ctx }) => {
      if (!ctx.db) throw new Error("Database not available");
      return ctx.db
        .select()
        .from(savedAccounts)
        .where(eq(savedAccounts.userId, ctx.user!.id))
        .execute();
    }),
    create: protectedProcedure
      .input(
        z.object({
          providerId: z.number(),
          accountNumber: z.string(),
          accountName: z.string().optional(),
        })
      )
      .mutation(async ({ ctx, input }) => {
        if (!ctx.db) throw new Error("Database not available");
        return await ctx.db.insert(savedAccounts).values({
          userId: ctx.user!.id,
          providerId: input.providerId,
          accountNumber: input.accountNumber,
          accountName: input.accountName || input.accountNumber,
        });
      }),
    delete: protectedProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ ctx, input }) => {
        if (!ctx.db) throw new Error("Database not available");
        return await ctx.db
          .delete(savedAccounts)
          .where(
            and(
              eq(savedAccounts.id, input.id),
              eq(savedAccounts.userId, ctx.user!.id)
            )
          );
      }),
  }),

  ussd: router({
    login: publicProcedure
      .input(z.object({ phoneNumber: z.string() }))
      .mutation(async ({ ctx, input }) => {
        if (!ctx.db) throw new Error("Database not available");
        await ctx.db.insert(ussdRequests).values({
          userId: ctx.user?.id || 0,
          requestType: "login",
          phoneNumber: input.phoneNumber,
          status: "completed",
        });
        return { success: true, message: "Tizimga kirishingiz muvaffaqiyatli" };
      }),
    register: publicProcedure
      .input(z.object({ phoneNumber: z.string() }))
      .mutation(async ({ ctx, input }) => {
        if (!ctx.db) throw new Error("Database not available");
        await ctx.db.insert(ussdRequests).values({
          userId: ctx.user?.id || 0,
          requestType: "register",
          phoneNumber: input.phoneNumber,
          status: "completed",
        });
        return { success: true, message: "Yangi raqamga ro'yxatdan o'tish muvaffaqiyatli" };
      }),
    checkBalance: publicProcedure
      .input(z.object({ phoneNumber: z.string() }))
      .mutation(async ({ ctx, input }) => {
        if (!ctx.db) throw new Error("Database not available");
        await ctx.db.insert(ussdRequests).values({
          userId: ctx.user?.id || 0,
          requestType: "balance_check",
          phoneNumber: input.phoneNumber,
          status: "completed",
        });
        return { success: true, message: "Balans: 0 UZS" };
      }),
  }),

  click: clickRouter,
});

export type AppRouter = typeof appRouter;
