import { useState, useEffect } from "react";

/**
 * Custom hook for managing LocalStorage
 * Supports save, read, and delete operations
 */
export function useLocalStorage<T>(key: string, initialValue?: T) {
  const [storedValue, setStoredValue] = useState<T | undefined>(() => {
    try {
      if (typeof window === "undefined") {
        return initialValue;
      }
      const item = window.localStorage.getItem(key);
      return item ? JSON.parse(item) : initialValue;
    } catch (error) {
      console.error(`Error reading from localStorage (${key}):`, error);
      return initialValue;
    }
  });

  const setValue = (value: T | ((val?: T) => T)) => {
    try {
      const valueToStore = value instanceof Function ? value(storedValue) : value;
      setStoredValue(valueToStore);
      if (typeof window !== "undefined") {
        window.localStorage.setItem(key, JSON.stringify(valueToStore));
      }
    } catch (error) {
      console.error(`Error writing to localStorage (${key}):`, error);
    }
  };

  const removeValue = () => {
    try {
      setStoredValue(undefined);
      if (typeof window !== "undefined") {
        window.localStorage.removeItem(key);
      }
    } catch (error) {
      console.error(`Error removing from localStorage (${key}):`, error);
    }
  };

  return [storedValue, setValue, removeValue] as const;
}

/**
 * Manage saved accounts in LocalStorage
 */
export interface SavedAccount {
  id: string;
  providerId: number;
  accountNumber: string;
  accountName: string;
  createdAt: string;
}

export function useSavedAccounts() {
  const [accounts, setAccounts, removeAccounts] = useLocalStorage<SavedAccount[]>(
    "kommunal_pay_accounts",
    []
  );

  const addAccount = (account: Omit<SavedAccount, "id" | "createdAt">) => {
    const newAccount: SavedAccount = {
      ...account,
      id: `${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
      createdAt: new Date().toISOString(),
    };
    setAccounts([...(accounts || []), newAccount]);
    return newAccount;
  };

  const deleteAccount = (id: string) => {
    setAccounts((accounts || []).filter((acc) => acc.id !== id));
  };

  const updateAccount = (id: string, updates: Partial<SavedAccount>) => {
    setAccounts(
      (accounts || []).map((acc) => (acc.id === id ? { ...acc, ...updates } : acc))
    );
  };

  return {
    accounts: accounts || [],
    addAccount,
    deleteAccount,
    updateAccount,
    clearAll: removeAccounts,
  };
}

/**
 * Manage payment history in LocalStorage
 */
export interface PaymentRecord {
  id: string;
  providerId: number;
  providerName: string;
  accountNumber: string;
  amount: number;
  status: "pending" | "completed" | "failed";
  receiptNumber: string;
  createdAt: string;
}

export function usePaymentHistory() {
  const [history, setHistory, removeHistory] = useLocalStorage<PaymentRecord[]>(
    "kommunal_pay_history",
    []
  );

  const addPayment = (payment: Omit<PaymentRecord, "id">) => {
    const newPayment: PaymentRecord = {
      ...payment,
      id: `${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
    };
    setHistory([newPayment, ...(history || [])]);
    return newPayment;
  };

  const deletePayment = (id: string) => {
    setHistory((history || []).filter((p) => p.id !== id));
  };

  const getPaymentsByProvider = (providerName: string) => {
    return (history || []).filter((p) => p.providerName === providerName);
  };

  const getPaymentsByDateRange = (startDate: Date, endDate: Date) => {
    return (history || []).filter((p) => {
      const paymentDate = new Date(p.createdAt);
      return paymentDate >= startDate && paymentDate <= endDate;
    });
  };

  return {
    history: history || [],
    addPayment,
    deletePayment,
    getPaymentsByProvider,
    getPaymentsByDateRange,
    clearAll: removeHistory,
  };
}
