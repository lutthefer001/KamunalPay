import { useState } from "react";
import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { trpc } from "@/lib/trpc";
import { ArrowLeft, Trash2, Download, CheckCircle, Clock, XCircle } from "lucide-react";
import { useLocation } from "wouter";

export default function PaymentHistory() {
  const [, setLocation] = useLocation();
  const { isAuthenticated } = useAuth();
  const [filterProvider, setFilterProvider] = useState<string>("");
  const [filterStatus, setFilterStatus] = useState<string>("");

  const { data: payments, isLoading } = trpc.payments.list.useQuery(undefined, {
    enabled: isAuthenticated,
  });

  const { data: providers } = trpc.providers.list.useQuery();

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-50 to-orange-50">
        <Card className="max-w-md shadow-lg">
          <CardContent className="pt-6">
            <p className="text-center text-lg">Iltimos, kirish uchun login qiling</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  const filteredPayments = payments?.filter((payment) => {
    if (filterProvider && filterProvider !== "all" && payment.providerId !== parseInt(filterProvider)) return false;
    if (filterStatus && filterStatus !== "all" && payment.status !== filterStatus) return false;
    return true;
  }) || [];

  const handleDelete = async (id: number) => {
    if (confirm("Haqiqatan ham o'chirib tashlamoqchisiz?")) {
      alert("Delettion feature coming soon");
    }
  };

  const handleExport = () => {
    const csv = [
      ["Chek Raqami", "Xizmat", "Hisob Raqami", "Summa", "Holati", "Vaqti"],
      ...filteredPayments.map((p) => [
        p.receiptNumber || "",
        providers?.find((pr) => pr.id === p.providerId)?.name || "",
        p.accountNumber,
        (p.amount / 100).toFixed(2),
        p.status,
        new Date(p.createdAt).toLocaleDateString("uz-UZ"),
      ]),
    ]
      .map((row) => row.map((cell) => `"${cell}"`).join(","))
      .join("\n");

    const blob = new Blob([csv], { type: "text/csv" });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "payment-history.csv";
    a.click();
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "completed":
        return <CheckCircle className="w-5 h-5 text-green-600" />;
      case "pending":
        return <Clock className="w-5 h-5 text-yellow-600" />;
      case "failed":
        return <XCircle className="w-5 h-5 text-red-600" />;
      default:
        return null;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "completed":
        return "bg-green-100 text-green-800 border-green-300";
      case "pending":
        return "bg-yellow-100 text-yellow-800 border-yellow-300";
      case "failed":
        return "bg-red-100 text-red-800 border-red-300";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-orange-50 py-8 px-4">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="flex items-center gap-4 mb-8 animate-slide-in-down">
          <Button
            variant="outline"
            size="icon"
            onClick={() => setLocation("/")}
            className="smooth-transition hover:shadow-lg hover:border-orange-500"
          >
            <ArrowLeft className="w-4 h-4" />
          </Button>
          <div>
            <h1 className="text-4xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-orange-600 to-blue-600">
              To'lov Tarixi
            </h1>
            <p className="text-muted-foreground">Barcha to'lovlaringizni ko'ring va boshqaring</p>
          </div>
        </div>

        {/* Filters */}
        <Card className="mb-6 border-2 border-orange-200 shadow-lg animate-slide-in-up">
          <CardHeader className="bg-gradient-to-r from-orange-50 to-blue-50">
            <CardTitle className="text-xl">🔍 Filtrlash</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4 pt-6">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="space-y-2">
                <Label className="font-semibold">Xizmat Turi</Label>
                <Select value={filterProvider} onValueChange={setFilterProvider}>
                  <SelectTrigger className="border-2 border-gray-200 hover:border-orange-500 smooth-transition">
                    <SelectValue placeholder="Barcha xizmatlar" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Barcha xizmatlar</SelectItem>
                    {providers?.map((p) => (
                      <SelectItem key={p.id} value={p.id.toString()}>
                        {p.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label className="font-semibold">Holati</Label>
                <Select value={filterStatus} onValueChange={setFilterStatus}>
                  <SelectTrigger className="border-2 border-gray-200 hover:border-blue-500 smooth-transition">
                    <SelectValue placeholder="Barcha holatlar" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Barcha holatlar</SelectItem>
                    <SelectItem value="completed">✓ Yakunlangan</SelectItem>
                    <SelectItem value="pending">⏳ Kutilmoqda</SelectItem>
                    <SelectItem value="failed">✗ Muvaffaqiyatsiz</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="flex items-end">
                <Button
                  onClick={handleExport}
                  variant="outline"
                  className="w-full payment-button border-2 border-green-500 hover:bg-green-50 hover:text-green-700"
                >
                  <Download className="w-4 h-4 mr-2" />
                  CSV Yuklash
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Payment List */}
        {isLoading ? (
          <div className="text-center py-12 animate-fade-in">
            <div className="inline-block">
              <div className="animate-spin rounded-full h-16 w-16 border-4 border-orange-200 border-t-orange-600 mb-4"></div>
            </div>
            <p className="text-lg text-foreground font-semibold">Yuklanmoqda...</p>
          </div>
        ) : filteredPayments.length === 0 ? (
          <Card className="border-2 border-dashed border-gray-300 animate-scale-in">
            <CardContent className="py-16 text-center">
              <div className="text-6xl mb-4">📭</div>
              <p className="text-muted-foreground text-lg font-semibold">To'lovlar topilmadi</p>
              <p className="text-muted-foreground text-sm mt-2">Filtrlash shartlarini o'zgartib ko'ring</p>
            </CardContent>
          </Card>
        ) : (
          <div className="space-y-3">
            {filteredPayments.map((payment, index) => {
              const provider = providers?.find((p) => p.id === payment.providerId);
              return (
                <Card
                  key={payment.id}
                  className="service-card border-2 border-gray-200 hover:border-orange-500 shadow-md hover:shadow-xl overflow-hidden group"
                  style={{
                    animationDelay: `${index * 50}ms`,
                  }}
                >
                  <CardContent className="pt-6">
                    <div className="grid grid-cols-1 md:grid-cols-6 gap-4 items-center">
                      {/* Provider */}
                      <div className="group-hover:bg-orange-50 p-2 rounded transition-colors duration-200">
                        <p className="text-xs text-muted-foreground font-semibold">Xizmat</p>
                        <p className="font-bold text-lg text-orange-600">{provider?.name}</p>
                      </div>

                      {/* Account Number */}
                      <div className="group-hover:bg-blue-50 p-2 rounded transition-colors duration-200">
                        <p className="text-xs text-muted-foreground font-semibold">Hisob Raqami</p>
                        <p className="font-mono font-semibold">{payment.accountNumber}</p>
                      </div>

                      {/* Amount */}
                      <div className="group-hover:bg-green-50 p-2 rounded transition-colors duration-200">
                        <p className="text-xs text-muted-foreground font-semibold">Summa</p>
                        <p className="font-bold text-lg text-transparent bg-clip-text bg-gradient-to-r from-orange-600 to-blue-600">
                          {(payment.amount / 100).toLocaleString("uz-UZ")} so'm
                        </p>
                      </div>

                      {/* Status */}
                      <div className="group-hover:bg-gray-50 p-2 rounded transition-colors duration-200">
                        <p className="text-xs text-muted-foreground font-semibold">Holati</p>
                        <div className="flex items-center gap-2 mt-1">
                          {getStatusIcon(payment.status)}
                          <span
                            className={`inline-block px-3 py-1 rounded-full text-xs font-bold border-2 ${getStatusColor(
                              payment.status
                            )}`}
                          >
                            {payment.status === "completed"
                              ? "Yakunlangan"
                              : payment.status === "pending"
                              ? "Kutilmoqda"
                              : "Muvaffaqiyatsiz"}
                          </span>
                        </div>
                      </div>

                      {/* Date */}
                      <div className="group-hover:bg-purple-50 p-2 rounded transition-colors duration-200">
                        <p className="text-xs text-muted-foreground font-semibold">Vaqti</p>
                        <p className="font-semibold text-sm">
                          {new Date(payment.createdAt).toLocaleDateString("uz-UZ")}
                        </p>
                      </div>

                      {/* Actions */}
                      <div className="flex gap-2">
                        <Button
                          onClick={() => handleDelete(payment.id)}
                          variant="ghost"
                          size="sm"
                          className="payment-button text-red-600 hover:bg-red-50 hover:text-red-700"
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}
