import { useState } from "react";
import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { trpc } from "@/lib/trpc";
import { ArrowLeft, Plus, TrendingUp, DollarSign, CreditCard, Zap } from "lucide-react";
import { useLocation } from "wouter";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

export default function ClickDashboard() {
  const [, setLocation] = useLocation();
  const { user } = useAuth();
  const [showLoanModal, setShowLoanModal] = useState(false);
  const [showCreditModal, setShowCreditModal] = useState(false);
  const [showEasyPaymentModal, setShowEasyPaymentModal] = useState(false);

  const [loanData, setLoanData] = useState({
    cardId: "",
    loanAmount: "",
    months: "12",
    interestRate: "0",
  });

  const [creditData, setCreditData] = useState({
    creditAmount: "",
    maxAmount: "",
    interestRate: "0",
    terms: "12",
  });

  const [easyPaymentData, setEasyPaymentData] = useState({
    cardId: "",
    paymentAmount: "",
    installments: "3",
    interestRate: "0",
  });

  const { data: stats } = trpc.click.stats.overview.useQuery();
  const { data: loans } = trpc.click.loans.list.useQuery();
  const { data: creditOffers } = trpc.click.creditOffers.list.useQuery();
  const { data: easyPayments } = trpc.click.easyPayments.list.useQuery();
  const { data: cards } = trpc.cards.list.useQuery();

  const createLoanMutation = trpc.click.loans.create.useMutation();
  const createCreditMutation = trpc.click.creditOffers.create.useMutation();
  const createEasyPaymentMutation = trpc.click.easyPayments.create.useMutation();

  const handleCreateLoan = async () => {
    try {
      if (!loanData.cardId || !loanData.loanAmount) {
        alert("Barcha maydonlarni to'ldiring");
        return;
      }

      await createLoanMutation.mutateAsync({
        cardId: parseInt(loanData.cardId),
        loanAmount: loanData.loanAmount,
        months: parseInt(loanData.months),
        interestRate: loanData.interestRate,
      });

      setLoanData({ cardId: "", loanAmount: "", months: "12", interestRate: "0" });
      setShowLoanModal(false);
    } catch (error) {
      alert("Qarz yaratishda xato: " + (error as any).message);
    }
  };

  const handleCreateCredit = async () => {
    try {
      if (!creditData.creditAmount || !creditData.maxAmount) {
        alert("Barcha maydonlarni to'ldiring");
        return;
      }

      await createCreditMutation.mutateAsync({
        creditAmount: creditData.creditAmount,
        maxAmount: creditData.maxAmount,
        interestRate: creditData.interestRate,
        terms: parseInt(creditData.terms),
      });

      setCreditData({ creditAmount: "", maxAmount: "", interestRate: "0", terms: "12" });
      setShowCreditModal(false);
    } catch (error) {
      alert("Kredit yaratishda xato: " + (error as any).message);
    }
  };

  const handleCreateEasyPayment = async () => {
    try {
      if (!easyPaymentData.cardId || !easyPaymentData.paymentAmount) {
        alert("Barcha maydonlarni to'ldiring");
        return;
      }

      await createEasyPaymentMutation.mutateAsync({
        cardId: parseInt(easyPaymentData.cardId),
        paymentAmount: easyPaymentData.paymentAmount,
        installments: parseInt(easyPaymentData.installments),
        interestRate: easyPaymentData.interestRate,
      });

      setEasyPaymentData({ cardId: "", paymentAmount: "", installments: "3", interestRate: "0" });
      setShowEasyPaymentModal(false);
    } catch (error) {
      alert("Oson to'lov yaratishda xato: " + (error as any).message);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-orange-50 py-8 px-4">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="flex items-center gap-4 mb-8 animate-slide-in-down">
          <Button
            variant="outline"
            size="icon"
            onClick={() => setLocation("/")}
            className="smooth-transition hover:shadow-lg hover:border-orange-500"
          >
            <ArrowLeft className="w-4 h-4" />
          </Button>
          <div>
            <h1 className="text-4xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-orange-600 to-blue-600">
              💳 Click Dashboard
            </h1>
            <p className="text-muted-foreground">Qarz, Kredit va Oson To'lovlarni boshqaring</p>
          </div>
        </div>

        {/* Statistics Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
          <Card className="border-2 border-orange-200 shadow-lg animate-slide-in-up">
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground font-semibold">Faol Qarzlar</p>
                  <p className="text-3xl font-bold text-orange-600">{stats?.activeLoans || 0}</p>
                </div>
                <DollarSign className="w-12 h-12 text-orange-200" />
              </div>
            </CardContent>
          </Card>

          <Card className="border-2 border-blue-200 shadow-lg animate-slide-in-up" style={{ animationDelay: "50ms" }}>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground font-semibold">Qolgan Qarz</p>
                  <p className="text-3xl font-bold text-blue-600">{(stats?.totalRemainingAmount || 0).toLocaleString()} so'm</p>
                </div>
                <TrendingUp className="w-12 h-12 text-blue-200" />
              </div>
            </CardContent>
          </Card>

          <Card className="border-2 border-green-200 shadow-lg animate-slide-in-up" style={{ animationDelay: "100ms" }}>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground font-semibold">Mavjud Kredit</p>
                  <p className="text-3xl font-bold text-green-600">{(stats?.totalCreditAvailable || 0).toLocaleString()} so'm</p>
                </div>
                <CreditCard className="w-12 h-12 text-green-200" />
              </div>
            </CardContent>
          </Card>

          <Card className="border-2 border-purple-200 shadow-lg animate-slide-in-up" style={{ animationDelay: "150ms" }}>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground font-semibold">Faol Oson To'lovlar</p>
                  <p className="text-3xl font-bold text-purple-600">{stats?.activeEasyPayments || 0}</p>
                </div>
                <Zap className="w-12 h-12 text-purple-200" />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Main Tabs */}
        <Tabs defaultValue="loans" className="w-full">
          <TabsList className="grid w-full grid-cols-3 mb-6">
            <TabsTrigger value="loans">Qarzlar</TabsTrigger>
            <TabsTrigger value="credit">Kreditlar</TabsTrigger>
            <TabsTrigger value="easy">Oson To'lovlar</TabsTrigger>
          </TabsList>

          {/* Loans Tab */}
          <TabsContent value="loans">
            <Card className="border-2 border-orange-200 shadow-lg">
              <CardHeader className="bg-gradient-to-r from-orange-50 to-orange-100 flex flex-row items-center justify-between">
                <div>
                  <CardTitle>Mening Qarzlarim</CardTitle>
                  <CardDescription>Qarz tarixini ko'ring va to'lovlarni amalga oshiring</CardDescription>
                </div>
                <Button
                  onClick={() => setShowLoanModal(true)}
                  className="gap-2 bg-gradient-to-r from-orange-500 to-orange-600 hover:from-orange-600 hover:to-orange-700"
                >
                  <Plus className="w-4 h-4" />
                  Qarz Olish
                </Button>
              </CardHeader>
              <CardContent className="pt-6">
                {!loans || loans.length === 0 ? (
                  <div className="text-center py-12">
                    <p className="text-muted-foreground text-lg">Qarzlar yo'q</p>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {loans.map((loan) => (
                      <div key={loan.id} className="border-2 border-gray-200 p-4 rounded-lg hover:shadow-lg smooth-transition">
                        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                          <div>
                            <p className="text-sm text-muted-foreground font-semibold">Qarz Summasi</p>
                            <p className="font-bold text-lg">{loan.loanAmount} so'm</p>
                          </div>
                          <div>
                            <p className="text-sm text-muted-foreground font-semibold">Oylik To'lov</p>
                            <p className="font-bold text-lg">{loan.monthlyPayment} so'm</p>
                          </div>
                          <div>
                            <p className="text-sm text-muted-foreground font-semibold">Qolgan Qarz</p>
                            <p className="font-bold text-lg text-orange-600">{loan.remainingAmount} so'm</p>
                          </div>
                          <div>
                            <p className="text-sm text-muted-foreground font-semibold">Holati</p>
                            <span className={`px-3 py-1 rounded-full text-xs font-bold border-2 ${
                              loan.status === "active"
                                ? "bg-green-100 text-green-800 border-green-300"
                                : loan.status === "completed"
                                ? "bg-blue-100 text-blue-800 border-blue-300"
                                : "bg-gray-100 text-gray-800 border-gray-300"
                            }`}>
                              {loan.status === "active" ? "Faol" : loan.status === "completed" ? "Tugatilgan" : "Kutilmoqda"}
                            </span>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Credit Tab */}
          <TabsContent value="credit">
            <Card className="border-2 border-green-200 shadow-lg">
              <CardHeader className="bg-gradient-to-r from-green-50 to-green-100 flex flex-row items-center justify-between">
                <div>
                  <CardTitle>Mening Kreditlarim</CardTitle>
                  <CardDescription>Mavjud kredit takliflarini ko'ring</CardDescription>
                </div>
                <Button
                  onClick={() => setShowCreditModal(true)}
                  className="gap-2 bg-gradient-to-r from-green-500 to-green-600 hover:from-green-600 hover:to-green-700"
                >
                  <Plus className="w-4 h-4" />
                  Kredit Taklifi
                </Button>
              </CardHeader>
              <CardContent className="pt-6">
                {!creditOffers || creditOffers.length === 0 ? (
                  <div className="text-center py-12">
                    <p className="text-muted-foreground text-lg">Kredit takliflari yo'q</p>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {creditOffers.map((offer) => (
                      <div key={offer.id} className="border-2 border-gray-200 p-4 rounded-lg hover:shadow-lg smooth-transition">
                        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                          <div>
                            <p className="text-sm text-muted-foreground font-semibold">Kredit Summasi</p>
                            <p className="font-bold text-lg">{offer.creditAmount} so'm</p>
                          </div>
                          <div>
                            <p className="text-sm text-muted-foreground font-semibold">Maksimal</p>
                            <p className="font-bold text-lg">{offer.maxAmount} so'm</p>
                          </div>
                          <div>
                            <p className="text-sm text-muted-foreground font-semibold">Foiz %</p>
                            <p className="font-bold text-lg text-green-600">{offer.interestRate}%</p>
                          </div>
                          <div>
                            <p className="text-sm text-muted-foreground font-semibold">Holati</p>
                            <span className="px-3 py-1 rounded-full text-xs font-bold border-2 bg-green-100 text-green-800 border-green-300">
                              {offer.status === "active" ? "Faol" : "Tugallangan"}
                            </span>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Easy Payments Tab */}
          <TabsContent value="easy">
            <Card className="border-2 border-purple-200 shadow-lg">
              <CardHeader className="bg-gradient-to-r from-purple-50 to-purple-100 flex flex-row items-center justify-between">
                <div>
                  <CardTitle>Oson To'lovlar</CardTitle>
                  <CardDescription>Oylik to'lovlar bilan xaridlarni amalga oshiring</CardDescription>
                </div>
                <Button
                  onClick={() => setShowEasyPaymentModal(true)}
                  className="gap-2 bg-gradient-to-r from-purple-500 to-purple-600 hover:from-purple-600 hover:to-purple-700"
                >
                  <Plus className="w-4 h-4" />
                  Oson To'lov
                </Button>
              </CardHeader>
              <CardContent className="pt-6">
                {!easyPayments || easyPayments.length === 0 ? (
                  <div className="text-center py-12">
                    <p className="text-muted-foreground text-lg">Oson to'lovlar yo'q</p>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {easyPayments.map((payment) => (
                      <div key={payment.id} className="border-2 border-gray-200 p-4 rounded-lg hover:shadow-lg smooth-transition">
                        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                          <div>
                            <p className="text-sm text-muted-foreground font-semibold">Umumiy Summa</p>
                            <p className="font-bold text-lg">{payment.paymentAmount} so'm</p>
                          </div>
                          <div>
                            <p className="text-sm text-muted-foreground font-semibold">Oylik To'lov</p>
                            <p className="font-bold text-lg">{payment.monthlyAmount} so'm</p>
                          </div>
                          <div>
                            <p className="text-sm text-muted-foreground font-semibold">Qisimlar</p>
                            <p className="font-bold text-lg text-purple-600">
                              {payment.paidInstallments || 0}/{payment.installments}
                            </p>
                          </div>
                          <div>
                            <p className="text-sm text-muted-foreground font-semibold">Holati</p>
                            <span className={`px-3 py-1 rounded-full text-xs font-bold border-2 ${
                              payment.status === "active"
                                ? "bg-purple-100 text-purple-800 border-purple-300"
                                : "bg-blue-100 text-blue-800 border-blue-300"
                            }`}>
                              {payment.status === "active" ? "Faol" : "Tugatilgan"}
                            </span>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>

      {/* Loan Modal */}
      <Dialog open={showLoanModal} onOpenChange={setShowLoanModal}>
        <DialogContent className="max-w-md animate-scale-in">
          <DialogHeader>
            <DialogTitle>Qarz Olish</DialogTitle>
          </DialogHeader>

          <div className="space-y-4">
            <div className="space-y-2">
              <Label className="font-semibold">Karta Tanlang</Label>
              <select
                value={loanData.cardId}
                onChange={(e) => setLoanData({ ...loanData, cardId: e.target.value })}
                className="w-full border-2 border-gray-200 rounded-lg p-2 focus:border-orange-500 smooth-transition"
              >
                <option value="">Kartani tanlang</option>
                {cards?.map((card) => (
                  <option key={card.id} value={card.id}>
                    {card.cardType} - {card.cardNumber.slice(-4)}
                  </option>
                ))}
              </select>
            </div>

            <div className="space-y-2">
              <Label className="font-semibold">Qarz Summasi (so'm)</Label>
              <Input
                type="number"
                placeholder="1000000"
                value={loanData.loanAmount}
                onChange={(e) => setLoanData({ ...loanData, loanAmount: e.target.value })}
                className="border-2 border-gray-200 focus:border-orange-500 smooth-transition"
              />
            </div>

            <div className="grid grid-cols-2 gap-2">
              <div className="space-y-2">
                <Label className="font-semibold">Oylar Soni</Label>
                <Input
                  type="number"
                  min="1"
                  max="60"
                  value={loanData.months}
                  onChange={(e) => setLoanData({ ...loanData, months: e.target.value })}
                  className="border-2 border-gray-200 focus:border-orange-500 smooth-transition"
                />
              </div>
              <div className="space-y-2">
                <Label className="font-semibold">Foiz %</Label>
                <Input
                  type="number"
                  step="0.1"
                  value={loanData.interestRate}
                  onChange={(e) => setLoanData({ ...loanData, interestRate: e.target.value })}
                  className="border-2 border-gray-200 focus:border-orange-500 smooth-transition"
                />
              </div>
            </div>
          </div>

          <DialogFooter className="flex gap-2">
            <Button onClick={() => setShowLoanModal(false)} variant="outline" className="flex-1">
              Bekor
            </Button>
            <Button
              onClick={handleCreateLoan}
              disabled={createLoanMutation.isPending}
              className="flex-1 bg-gradient-to-r from-orange-500 to-orange-600 hover:from-orange-600 hover:to-orange-700 text-white font-bold"
            >
              {createLoanMutation.isPending ? "Yaratilmoqda..." : "Qarz Olish"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Credit Modal */}
      <Dialog open={showCreditModal} onOpenChange={setShowCreditModal}>
        <DialogContent className="max-w-md animate-scale-in">
          <DialogHeader>
            <DialogTitle>Kredit Taklifi</DialogTitle>
          </DialogHeader>

          <div className="space-y-4">
            <div className="space-y-2">
              <Label className="font-semibold">Kredit Summasi (so'm)</Label>
              <Input
                type="number"
                placeholder="500000"
                value={creditData.creditAmount}
                onChange={(e) => setCreditData({ ...creditData, creditAmount: e.target.value })}
                className="border-2 border-gray-200 focus:border-green-500 smooth-transition"
              />
            </div>

            <div className="space-y-2">
              <Label className="font-semibold">Maksimal Summa (so'm)</Label>
              <Input
                type="number"
                placeholder="5000000"
                value={creditData.maxAmount}
                onChange={(e) => setCreditData({ ...creditData, maxAmount: e.target.value })}
                className="border-2 border-gray-200 focus:border-green-500 smooth-transition"
              />
            </div>

            <div className="grid grid-cols-2 gap-2">
              <div className="space-y-2">
                <Label className="font-semibold">Foiz %</Label>
                <Input
                  type="number"
                  step="0.1"
                  value={creditData.interestRate}
                  onChange={(e) => setCreditData({ ...creditData, interestRate: e.target.value })}
                  className="border-2 border-gray-200 focus:border-green-500 smooth-transition"
                />
              </div>
              <div className="space-y-2">
                <Label className="font-semibold">Muddati (oylar)</Label>
                <Input
                  type="number"
                  value={creditData.terms}
                  onChange={(e) => setCreditData({ ...creditData, terms: e.target.value })}
                  className="border-2 border-gray-200 focus:border-green-500 smooth-transition"
                />
              </div>
            </div>
          </div>

          <DialogFooter className="flex gap-2">
            <Button onClick={() => setShowCreditModal(false)} variant="outline" className="flex-1">
              Bekor
            </Button>
            <Button
              onClick={handleCreateCredit}
              disabled={createCreditMutation.isPending}
              className="flex-1 bg-gradient-to-r from-green-500 to-green-600 hover:from-green-600 hover:to-green-700 text-white font-bold"
            >
              {createCreditMutation.isPending ? "Yaratilmoqda..." : "Taklif Yaratish"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Easy Payment Modal */}
      <Dialog open={showEasyPaymentModal} onOpenChange={setShowEasyPaymentModal}>
        <DialogContent className="max-w-md animate-scale-in">
          <DialogHeader>
            <DialogTitle>Oson To'lov</DialogTitle>
          </DialogHeader>

          <div className="space-y-4">
            <div className="space-y-2">
              <Label className="font-semibold">Karta Tanlang</Label>
              <select
                value={easyPaymentData.cardId}
                onChange={(e) => setEasyPaymentData({ ...easyPaymentData, cardId: e.target.value })}
                className="w-full border-2 border-gray-200 rounded-lg p-2 focus:border-purple-500 smooth-transition"
              >
                <option value="">Kartani tanlang</option>
                {cards?.map((card) => (
                  <option key={card.id} value={card.id}>
                    {card.cardType} - {card.cardNumber.slice(-4)}
                  </option>
                ))}
              </select>
            </div>

            <div className="space-y-2">
              <Label className="font-semibold">To'lov Summasi (so'm)</Label>
              <Input
                type="number"
                placeholder="2000000"
                value={easyPaymentData.paymentAmount}
                onChange={(e) => setEasyPaymentData({ ...easyPaymentData, paymentAmount: e.target.value })}
                className="border-2 border-gray-200 focus:border-purple-500 smooth-transition"
              />
            </div>

            <div className="grid grid-cols-2 gap-2">
              <div className="space-y-2">
                <Label className="font-semibold">Qisimlar</Label>
                <Input
                  type="number"
                  min="2"
                  max="12"
                  value={easyPaymentData.installments}
                  onChange={(e) => setEasyPaymentData({ ...easyPaymentData, installments: e.target.value })}
                  className="border-2 border-gray-200 focus:border-purple-500 smooth-transition"
                />
              </div>
              <div className="space-y-2">
                <Label className="font-semibold">Foiz %</Label>
                <Input
                  type="number"
                  step="0.1"
                  value={easyPaymentData.interestRate}
                  onChange={(e) => setEasyPaymentData({ ...easyPaymentData, interestRate: e.target.value })}
                  className="border-2 border-gray-200 focus:border-purple-500 smooth-transition"
                />
              </div>
            </div>
          </div>

          <DialogFooter className="flex gap-2">
            <Button onClick={() => setShowEasyPaymentModal(false)} variant="outline" className="flex-1">
              Bekor
            </Button>
            <Button
              onClick={handleCreateEasyPayment}
              disabled={createEasyPaymentMutation.isPending}
              className="flex-1 bg-gradient-to-r from-purple-500 to-purple-600 hover:from-purple-600 hover:to-purple-700 text-white font-bold"
            >
              {createEasyPaymentMutation.isPending ? "Yaratilmoqda..." : "Oson To'lov Qo'shish"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
