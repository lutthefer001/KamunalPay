import { useState } from "react";
import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { trpc } from "@/lib/trpc";
import { getLoginUrl } from "@/const";
import { Zap, Droplets, Flame, Smartphone, Wifi, Tv, Phone, Globe, Gift, CreditCard, History, ArrowRight, LogOut } from "lucide-react";
import { useLocation, Link } from "wouter";
import { PaymentConfirmationModal } from "@/components/PaymentConfirmationModal";

interface ServiceType {
  id: string;
  category: string;
  label: string;
  icon: React.ReactNode;
  color: string;
  gradientFrom: string;
  gradientTo: string;
}

const SERVICE_CATEGORIES: ServiceType[] = [
  {
    id: "utilities",
    category: "utilities",
    label: "Kommunal Xizmatlar",
    icon: <Flame className="w-8 h-8" />,
    color: "bg-orange-900/20 border-orange-700/50",
    gradientFrom: "from-orange-500",
    gradientTo: "to-orange-700",
  },
  {
    id: "mobile",
    category: "mobile",
    label: "Uyali Aloqa",
    icon: <Smartphone className="w-8 h-8" />,
    color: "bg-purple-900/20 border-purple-700/50",
    gradientFrom: "from-purple-500",
    gradientTo: "to-purple-700",
  },
  {
    id: "internet",
    category: "internet",
    label: "Internet",
    icon: <Wifi className="w-8 h-8" />,
    color: "bg-blue-900/20 border-blue-700/50",
    gradientFrom: "from-blue-500",
    gradientTo: "to-blue-700",
  },
  {
    id: "tv",
    category: "tv",
    label: "Televedeniye",
    icon: <Tv className="w-8 h-8" />,
    color: "bg-cyan-900/20 border-cyan-700/50",
    gradientFrom: "from-cyan-500",
    gradientTo: "to-cyan-700",
  },
  {
    id: "phone",
    category: "phone",
    label: "Telefoniya",
    icon: <Phone className="w-8 h-8" />,
    color: "bg-green-900/20 border-green-700/50",
    gradientFrom: "from-green-500",
    gradientTo: "to-green-700",
  },
  {
    id: "hosting",
    category: "hosting",
    label: "Saytlar Hosting",
    icon: <Globe className="w-8 h-8" />,
    color: "bg-indigo-900/20 border-indigo-700/50",
    gradientFrom: "from-indigo-500",
    gradientTo: "to-indigo-700",
  },
  {
    id: "other",
    category: "other",
    label: "Boshqa Xizmatlar",
    icon: <Gift className="w-8 h-8" />,
    color: "bg-pink-900/20 border-pink-700/50",
    gradientFrom: "from-pink-500",
    gradientTo: "to-pink-700",
  },
  {
    id: "transfer",
    category: "transfer",
    label: "Pul O'tkazmalari",
    icon: <CreditCard className="w-8 h-8" />,
    color: "bg-yellow-900/20 border-yellow-700/50",
    gradientFrom: "from-yellow-500",
    gradientTo: "to-yellow-700",
  },
];

export default function Home() {
  const [, setLocation] = useLocation();
  const { user, loading, error, isAuthenticated, logout, refresh } = useAuth();
  const [selectedCategory, setSelectedCategory] = useState<string>("");
  const [selectedProvider, setSelectedProvider] = useState<string>("");
  const [accountNumber, setAccountNumber] = useState<string>("");
  const [paymentAmount, setPaymentAmount] = useState<string>("");
  const [showConfirmation, setShowConfirmation] = useState(false);
  const [pendingPayment, setPendingPayment] = useState<any>(null);

  const { data: providers } = trpc.providers.list.useQuery();
  const { data: savedAccounts } = trpc.savedAccounts.list.useQuery();
  const createPaymentMutation = trpc.payments.create.useMutation();

  const filteredProviders = providers?.filter(
    (p) => p.serviceCategory === selectedCategory
  ) || [];

  const handlePayment = async () => {
    if (!selectedProvider || !accountNumber || !paymentAmount) {
      alert("Barcha maydonlarni to'ldiring");
      return;
    }

    const provider = providers?.find((p) => p.id.toString() === selectedProvider);
    if (!provider) return;

    setPendingPayment({
      provider: provider.name,
      accountNumber,
      paymentAmount,
      timestamp: new Date().toLocaleString("uz-UZ"),
    });

    setShowConfirmation(true);
  };

  const handleConfirmPayment = async () => {
    try {
      await createPaymentMutation.mutateAsync({
        providerId: selectedProvider ? parseInt(selectedProvider) : 0,
        accountNumber,
        amount: parseFloat(paymentAmount) || 0,
      });

      setSelectedCategory("");
      setSelectedProvider("");
      setAccountNumber("");
      setPaymentAmount("");
      setShowConfirmation(false);
      alert("To'lov muvaffaqiyatli amalga oshirildi!");
    } catch (error) {
      alert("Xato: " + (error as any).message);
    }
  };

  if (!isAuthenticated && !loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-gray-900 via-black to-gray-900 flex items-center justify-center px-4">
        <div className="text-center max-w-md">
          <h1 className="text-4xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-orange-500 to-blue-500 mb-4">
            Kommunal Pay
          </h1>
          <p className="text-gray-300 mb-8">Xush kelibsiz! Tizimga kirish uchun tugmani bosing.</p>
          <a href={getLoginUrl()}>
            <Button className="w-full bg-gradient-to-r from-orange-500 to-orange-600 hover:from-orange-600 hover:to-orange-700 text-white font-bold py-6 text-lg">
              🔐 Kirish
            </Button>
          </a>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-black to-gray-900 py-8 px-4">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="flex items-center justify-between mb-12 animate-slide-in-down">
          <div>
            <h1 className="text-5xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-orange-500 to-blue-500 mb-2">
              💳 Kommunal Pay
            </h1>
            <p className="text-lg text-gray-400">
              Xush kelibsiz, {user?.name || "Foydalanuvchi"}! 👋
            </p>
          </div>
          <div className="flex gap-2 flex-wrap">
            <Link href="/profile">
              <Button 
                variant="outline" 
                size="lg" 
                className="gap-2 smooth-transition hover:shadow-lg hover:border-blue-500 hover:text-blue-400 bg-gray-800 border-gray-700 text-gray-300"
              >
                👤 Profil
              </Button>
            </Link>
            <Link href="/click">
              <Button 
                variant="outline" 
                size="lg" 
                className="gap-2 smooth-transition hover:shadow-lg hover:border-purple-500 hover:text-purple-400 bg-gray-800 border-gray-700 text-gray-300"
              >
                💳 Click
              </Button>
            </Link>
            <Link href="/loan-payment">
              <Button 
                variant="outline" 
                size="lg" 
                className="gap-2 smooth-transition hover:shadow-lg hover:border-pink-500 hover:text-pink-400 bg-gray-800 border-gray-700 text-gray-300"
              >
                🏦 Qarz
              </Button>
            </Link>
            <Link href="/history">
              <Button 
                variant="outline" 
                size="lg" 
                className="gap-2 smooth-transition hover:shadow-lg hover:border-orange-500 hover:text-orange-400 bg-gray-800 border-gray-700 text-gray-300"
              >
                <History className="w-5 h-5" />
                Tarix
              </Button>
            </Link>
            <Button
              onClick={() => logout()}
              variant="outline"
              size="lg"
              className="gap-2 smooth-transition hover:shadow-lg hover:border-red-500 hover:text-red-400 bg-gray-800 border-gray-700 text-gray-300"
            >
              <LogOut className="w-5 h-5" />
              Chiqish
            </Button>
          </div>
        </div>

        {/* Service Categories Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-12">
          {SERVICE_CATEGORIES.map((service, index) => (
            <button
              key={service.id}
              onClick={() => {
                setSelectedCategory(service.category);
                setSelectedProvider("");
              }}
              className={`animate-slide-in-up smooth-transition transform hover:-translate-y-2 hover:shadow-2xl`}
              style={{ animationDelay: `${index * 50}ms` }}
            >
              <Card
                className={`border-2 cursor-pointer h-full ${
                  selectedCategory === service.category
                    ? `${service.color} ring-2 ring-offset-2 ring-offset-gray-900`
                    : `${service.color} hover:shadow-xl`
                }`}
              >
                <CardContent className="pt-8 pb-6 text-center">
                  <div className={`inline-block p-4 rounded-full bg-gradient-to-br ${service.gradientFrom} ${service.gradientTo} mb-4 text-white`}>
                    {service.icon}
                  </div>
                  <h3 className="font-bold text-lg text-gray-100">{service.label}</h3>
                </CardContent>
              </Card>
            </button>
          ))}
        </div>

        {/* Payment Form */}
        {selectedCategory && (
          <Card className="border-2 border-gray-700 shadow-2xl bg-gray-800/50 backdrop-blur animate-scale-in mb-8">
            <CardHeader className="bg-gradient-to-r from-orange-900/30 to-blue-900/30 border-b border-gray-700">
              <CardTitle className="text-gray-100">To'lov Formasini To'ldiring</CardTitle>
              <CardDescription className="text-gray-400">
                {SERVICE_CATEGORIES.find((s) => s.category === selectedCategory)?.label} uchun to'lov
              </CardDescription>
            </CardHeader>
            <CardContent className="pt-6 space-y-6">
              {/* Provider Selection */}
              <div className="space-y-2">
                <Label className="text-gray-300 font-semibold">Provayderni Tanlang</Label>
                <Select value={selectedProvider} onValueChange={setSelectedProvider}>
                  <SelectTrigger className="border-2 border-gray-600 bg-gray-700 text-gray-100 focus:border-orange-500 smooth-transition">
                    <SelectValue placeholder="Provayderni tanlang..." />
                  </SelectTrigger>
                  <SelectContent className="bg-gray-800 border-gray-700">
                    {filteredProviders.map((provider) => (
                      <SelectItem key={provider.id} value={provider.id.toString()} className="text-gray-100">
                        {provider.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              {/* Account Number */}
              <div className="space-y-2">
                <Label className="text-gray-300 font-semibold">Hisob Raqami</Label>
                <div className="flex gap-2">
                  <Input
                    type="text"
                    placeholder="Hisob raqamini kiriting"
                    value={accountNumber}
                    onChange={(e) => setAccountNumber(e.target.value)}
                    className="border-2 border-gray-600 bg-gray-700 text-gray-100 placeholder-gray-500 focus:border-orange-500 smooth-transition flex-1"
                  />
                  {savedAccounts && savedAccounts.length > 0 && (
                    <Select value={accountNumber} onValueChange={setAccountNumber}>
                      <SelectTrigger className="border-2 border-gray-600 bg-gray-700 text-gray-100 focus:border-blue-500 smooth-transition w-48">
                        <SelectValue placeholder="Saqlangan..." />
                      </SelectTrigger>
                      <SelectContent className="bg-gray-800 border-gray-700">
                        {savedAccounts.map((account) => (
                          <SelectItem key={account.id} value={account.accountNumber} className="text-gray-100">
                            {account.accountNumber}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  )}
                </div>
              </div>

              {/* Payment Amount */}
              <div className="space-y-2">
                <Label className="text-gray-300 font-semibold">To'lov Summasi (so'm)</Label>
                <Input
                  type="number"
                  placeholder="0"
                  value={paymentAmount}
                  onChange={(e) => setPaymentAmount(e.target.value)}
                  className="border-2 border-gray-600 bg-gray-700 text-gray-100 placeholder-gray-500 focus:border-orange-500 smooth-transition"
                />
              </div>

              {/* Payment Button */}
              <Button
                onClick={handlePayment}
                disabled={createPaymentMutation.isPending}
                className="w-full bg-gradient-to-r from-orange-500 to-orange-600 hover:from-orange-600 hover:to-orange-700 text-white font-bold py-6 text-lg smooth-transition"
              >
                {createPaymentMutation.isPending ? "Jarayonda..." : "To'lovni Tasdiqlash"}
                <ArrowRight className="w-5 h-5 ml-2" />
              </Button>
            </CardContent>
          </Card>
        )}
      </div>

      {/* Payment Confirmation Modal */}
      {showConfirmation && pendingPayment && (
        <PaymentConfirmationModal
          isOpen={showConfirmation}
          onClose={() => setShowConfirmation(false)}
          paymentData={pendingPayment}
        />
      )}
    </div>
  );
}
