import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { trpc } from "@/lib/trpc";
import { ArrowLeft, CreditCard, TrendingDown } from "lucide-react";
import { useLocation } from "wouter";
import { useState } from "react";

const DAILY_PAYMENT = 10000; // 10 million so'm

export default function LoanPayment() {
  const [, setLocation] = useLocation();
  const { user } = useAuth();
  const [paymentAmount, setPaymentAmount] = useState<string>("");
  const [selectedCard, setSelectedCard] = useState<string>("");

  const { data: loans } = trpc.click.loans.list.useQuery();
  const { data: cards } = trpc.cards.list.useQuery();
  const createPaymentMutation = trpc.payments.create.useMutation();

  // Calculate loan details
  const totalLoan = loans?.reduce((sum, loan) => sum + (parseInt(loan.loanAmount) || 0), 0) || 0;
  const totalPaid = loans?.reduce((sum, loan) => sum + (loan.paidAmount ? parseInt(loan.paidAmount) : 0), 0) || 0;
  const remainingLoan = totalLoan - totalPaid;
  const daysRemaining = Math.ceil(remainingLoan / DAILY_PAYMENT);

  const handlePayment = async () => {
    if (!paymentAmount || !selectedCard) {
      alert("Iltimos, to'lov summasi va kartani tanlang");
      return;
    }

    try {
      const amount = parseInt(paymentAmount);
      if (amount <= 0) {
        alert("To'lov summasi 0 dan katta bo'lishi kerak");
        return;
      }

      if (amount > remainingLoan) {
        alert(`Qolgan qarz ${remainingLoan} so'm. Bundan ko'p to'lova olmaysiz.`);
        return;
      }

      await createPaymentMutation.mutateAsync({
        amount,
        cardId: parseInt(selectedCard),
        accountNumber: "",
        providerId: 1, // Click provider ID
      });

      alert("Qarz to'lovi muvaffaqiyatli amalga oshdi!");
      setPaymentAmount("");
      setSelectedCard("");
    } catch (error) {
      alert("Xato: " + (error as any).message);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-black to-gray-900 py-8 px-4">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="flex items-center gap-4 mb-8 animate-slide-in-down">
          <Button
            variant="outline"
            size="icon"
            onClick={() => setLocation("/")}
            className="smooth-transition hover:shadow-lg hover:border-orange-500"
          >
            <ArrowLeft className="w-4 h-4" />
          </Button>
          <div>
            <h1 className="text-4xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-orange-500 to-blue-500">
              💰 Qarz To'lovi
            </h1>
            <p className="text-gray-400">Click Qarz'ingizni to'lash</p>
          </div>
        </div>

        {/* Loan Status */}
        <Card className="mb-6 border-2 border-gray-700 bg-gray-800/50 backdrop-blur animate-slide-in-up">
          <CardHeader className="bg-gradient-to-r from-orange-900/30 to-blue-900/30 border-b border-gray-700">
            <CardTitle className="text-2xl text-gray-100">📊 Qarz Holati</CardTitle>
          </CardHeader>
          <CardContent className="pt-6 space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {/* Total Loan */}
              <div className="bg-gradient-to-br from-red-900/30 to-red-800/30 p-4 rounded-lg border-2 border-red-700">
                <p className="text-sm text-gray-400 font-semibold">Umumiy Qarz</p>
                <p className="text-3xl font-bold text-red-400">{totalLoan.toLocaleString()} so'm</p>
              </div>

              {/* Paid Amount */}
              <div className="bg-gradient-to-br from-green-900/30 to-green-800/30 p-4 rounded-lg border-2 border-green-700">
                <p className="text-sm text-gray-400 font-semibold">To'langan</p>
                <p className="text-3xl font-bold text-green-400">{totalPaid.toLocaleString()} so'm</p>
              </div>

              {/* Remaining Loan */}
              <div className="bg-gradient-to-br from-orange-900/30 to-orange-800/30 p-4 rounded-lg border-2 border-orange-700">
                <p className="text-sm text-gray-400 font-semibold">Qolgan Qarz</p>
                <p className="text-3xl font-bold text-orange-400">{remainingLoan.toLocaleString()} so'm</p>
              </div>
            </div>

            {/* Payment Schedule */}
            <div className="bg-gray-700/30 p-4 rounded-lg border-2 border-gray-600">
              <div className="flex items-center gap-2 mb-2">
                <TrendingDown className="w-5 h-5 text-blue-400" />
                <p className="text-sm text-gray-400 font-semibold">Kunlik To'lov Grafigi</p>
              </div>
              <p className="text-lg font-bold text-gray-100">
                Har kun: <span className="text-blue-400">{DAILY_PAYMENT.toLocaleString()} so'm</span>
              </p>
              <p className="text-sm text-gray-400 mt-2">
                Qolgan kunlar: <span className="text-orange-400 font-bold">{daysRemaining} kun</span>
              </p>
            </div>
          </CardContent>
        </Card>

        {/* Payment Form */}
        <Card className="border-2 border-gray-700 bg-gray-800/50 backdrop-blur animate-scale-in">
          <CardHeader className="bg-gradient-to-r from-blue-900/30 to-purple-900/30 border-b border-gray-700">
            <CardTitle className="text-2xl text-gray-100">💳 To'lov Forması</CardTitle>
            <CardDescription className="text-gray-400">Qarzni to'lash uchun kartani tanlang</CardDescription>
          </CardHeader>
          <CardContent className="pt-6 space-y-6">
            {/* Card Selection */}
            <div className="space-y-2">
              <Label className="font-semibold text-gray-100">Karta Tanlang</Label>
              <select
                value={selectedCard}
                onChange={(e) => setSelectedCard(e.target.value)}
                className="w-full border-2 border-gray-600 bg-gray-700 text-gray-100 p-3 rounded-lg focus:border-orange-500 smooth-transition"
              >
                <option value="">-- Kartani tanlang --</option>
                {cards?.map((card) => (
                  <option key={card.id} value={card.id.toString()}>
                    {card.cardType.toUpperCase()} - **** {card.cardNumber.slice(-4)} ({(card.balance || 0).toLocaleString()} so'm)
                  </option>
                ))}
              </select>
            </div>

            {/* Payment Amount */}
            <div className="space-y-2">
              <Label className="font-semibold text-gray-100">To'lov Summasi (so'm)</Label>
              <div className="flex gap-2">
                <Input
                  type="number"
                  placeholder="Summani kiriting"
                  value={paymentAmount}
                  onChange={(e) => setPaymentAmount(e.target.value)}
                  className="border-2 border-gray-600 bg-gray-700 text-gray-100 placeholder-gray-500 focus:border-orange-500 smooth-transition flex-1"
                />
                <Button
                  onClick={() => setPaymentAmount(DAILY_PAYMENT.toString())}
                  variant="outline"
                  className="border-blue-500 text-blue-400 hover:bg-blue-900/20"
                >
                  Kunlik
                </Button>
                <Button
                  onClick={() => setPaymentAmount(remainingLoan.toString())}
                  variant="outline"
                  className="border-green-500 text-green-400 hover:bg-green-900/20"
                >
                  Barchasi
                </Button>
              </div>
            </div>

            {/* Quick Actions */}
            <div className="grid grid-cols-2 gap-2">
              <Button
                onClick={() => setPaymentAmount((DAILY_PAYMENT * 7).toString())}
                variant="outline"
                className="border-gray-600 text-gray-300 hover:bg-gray-700"
              >
                7 kun
              </Button>
              <Button
                onClick={() => setPaymentAmount((DAILY_PAYMENT * 30).toString())}
                variant="outline"
                className="border-gray-600 text-gray-300 hover:bg-gray-700"
              >
                1 oy
              </Button>
            </div>

            {/* Payment Button */}
            <Button
              onClick={handlePayment}
              disabled={createPaymentMutation.isPending || !paymentAmount || !selectedCard}
              className="w-full payment-button bg-gradient-to-r from-orange-500 to-blue-600 hover:from-orange-600 hover:to-blue-700 text-white font-bold py-6 text-lg"
            >
              {createPaymentMutation.isPending ? "Yuklanmoqda..." : "💰 To'lovni Tasdiqlash"}
            </Button>
          </CardContent>
        </Card>

        {/* Loan History */}
        {loans && loans.length > 0 && (
          <Card className="mt-6 border-2 border-gray-700 bg-gray-800/50 backdrop-blur">
            <CardHeader className="bg-gradient-to-r from-purple-900/30 to-pink-900/30 border-b border-gray-700">
              <CardTitle className="text-2xl text-gray-100">📋 Qarz Tarixi</CardTitle>
            </CardHeader>
            <CardContent className="pt-6">
              <div className="space-y-3">
                {loans.map((loan) => (
                  <div
                    key={loan.id}
                    className="bg-gray-700/30 p-4 rounded-lg border-2 border-gray-600 flex justify-between items-center"
                  >
                    <div>
                      <p className="font-semibold text-gray-100">Click Qarz</p>
                      <p className="text-sm text-gray-400">Sana: {new Date(loan.createdAt).toLocaleDateString("uz-UZ")}</p>
                    </div>
                    <div className="text-right">
                      <p className="font-bold text-orange-400">{parseInt(loan.loanAmount).toLocaleString()} so'm</p>
                      <p className="text-sm text-green-400">To'langan: {(loan.paidAmount ? parseInt(loan.paidAmount) : 0).toLocaleString()} so'm</p>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}
