import { useState } from "react";
import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { trpc } from "@/lib/trpc";
import { ArrowLeft, Edit2, Save, X, Plus, Trash2, CreditCard } from "lucide-react";
import { useLocation } from "wouter";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";

export default function Profile() {
  const [, setLocation] = useLocation();
  const { user } = useAuth();
  const [isEditing, setIsEditing] = useState(false);
  const [showCardModal, setShowCardModal] = useState(false);
  const [editData, setEditData] = useState({
    name: user?.name || "",
    phone: user?.phone || "",
    address: user?.address || "",
  });

  const [cardData, setCardData] = useState({
    cardNumber: "",
    cardHolder: "",
    expiryMonth: "",
    expiryYear: "",
    cvv: "",
    cardType: "uzcard" as const,
  });

  const { data: profile } = trpc.profile.get.useQuery();
  const { data: cards } = trpc.cards.list.useQuery();
  const updateProfileMutation = trpc.profile.update.useMutation();
  const createCardMutation = trpc.cards.create.useMutation();
  const deleteCardMutation = trpc.cards.delete.useMutation();

  const handleSaveProfile = async () => {
    try {
      await updateProfileMutation.mutateAsync(editData);
      setIsEditing(false);
    } catch (error) {
      alert("Profil yangilanishida xato: " + (error as any).message);
    }
  };

  const handleAddCard = async () => {
    try {
      // Validate
      if (!cardData.cardNumber || !cardData.cardHolder || !cardData.expiryMonth || !cardData.expiryYear || !cardData.cvv) {
        alert("Barcha maydonlarni to'ldiring");
        return;
      }

      await createCardMutation.mutateAsync({
        cardNumber: cardData.cardNumber.replace(/\s/g, ""),
        cardHolder: cardData.cardHolder,
        expiryMonth: parseInt(cardData.expiryMonth),
        expiryYear: parseInt(cardData.expiryYear),
        cvv: cardData.cvv,
        cardType: cardData.cardType,
      });

      setCardData({
        cardNumber: "",
        cardHolder: "",
        expiryMonth: "",
        expiryYear: "",
        cvv: "",
        cardType: "uzcard",
      });
      setShowCardModal(false);
    } catch (error) {
      alert("Karta qo'shishida xato: " + (error as any).message);
    }
  };

  const handleDeleteCard = async (cardId: number) => {
    if (confirm("Kartani o'chirib tashlamoqchimisiz?")) {
      try {
        await deleteCardMutation.mutateAsync({ cardId });
      } catch (error) {
        alert("Kartani o'chirishda xato: " + (error as any).message);
      }
    }
  };

  const maskCardNumber = (cardNumber: string) => {
    const last4 = cardNumber.slice(-4);
    return `**** **** **** ${last4}`;
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-black to-gray-900 py-8 px-4">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="flex items-center gap-4 mb-8 animate-slide-in-down">
          <Button
            variant="outline"
            size="icon"
            onClick={() => setLocation("/")}
            className="smooth-transition hover:shadow-lg hover:border-orange-500"
          >
            <ArrowLeft className="w-4 h-4" />
          </Button>
          <div>
            <h1 className="text-4xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-orange-600 to-blue-600">
              Profil
            </h1>
            <p className="text-muted-foreground">Shaxsiy ma'lumotlar va kartalarni boshqaring</p>
          </div>
        </div>

        {/* Profile Section */}
        <Card className="mb-6 border-2 border-gray-700 shadow-lg animate-slide-in-up bg-gray-800/50 backdrop-blur">
          <CardHeader className="bg-gradient-to-r from-orange-900/30 to-blue-900/30 border-b border-gray-700 flex flex-row items-center justify-between">
            <div>
              <CardTitle className="text-2xl text-gray-100">👤 Shaxsiy Ma'lumotlar</CardTitle>
              <CardDescription className="text-gray-400">Sizning profil ma'lumotlarini o'zgartiring</CardDescription>
            </div>
            {!isEditing && (
              <Button
                onClick={() => setIsEditing(true)}
                variant="outline"
                className="gap-2"
              >
                <Edit2 className="w-4 h-4" />
                Tahrir
              </Button>
            )}
          </CardHeader>
          <CardContent className="pt-6 space-y-6">
            {isEditing ? (
              <>
                <div className="space-y-2">
                  <Label className="font-semibold">Ism</Label>
                  <Input
                    value={editData.name}
                    onChange={(e) => setEditData({ ...editData, name: e.target.value })}
                    className="border-2 border-gray-600 bg-gray-700 text-gray-100 focus:border-orange-500 smooth-transition"
                  />
                </div>

                <div className="space-y-2">
                  <Label className="font-semibold">Telefon</Label>
                  <Input
                    value={editData.phone}
                    onChange={(e) => setEditData({ ...editData, phone: e.target.value })}
                    placeholder="+998 XX XXX XX XX"
                    className="border-2 border-gray-600 bg-gray-700 text-gray-100 placeholder-gray-500 focus:border-orange-500 smooth-transition"
                  />
                </div>

                <div className="space-y-2">
                  <Label className="font-semibold">Manzil</Label>
                  <Input
                    value={editData.address}
                    onChange={(e) => setEditData({ ...editData, address: e.target.value })}
                    placeholder="Shahar, ko'cha, uy raqami"
                    className="border-2 border-gray-600 bg-gray-700 text-gray-100 placeholder-gray-500 focus:border-orange-500 smooth-transition"
                  />
                </div>

                <div className="flex gap-2">
                  <Button
                    onClick={handleSaveProfile}
                    disabled={updateProfileMutation.isPending}
                    className="flex-1 payment-button bg-gradient-to-r from-orange-500 to-blue-600 hover:from-orange-600 hover:to-blue-700 text-white font-bold"
                  >
                    <Save className="w-4 h-4 mr-2" />
                    Saqlash
                  </Button>
                  <Button
                    onClick={() => setIsEditing(false)}
                    variant="outline"
                    className="flex-1"
                  >
                    <X className="w-4 h-4 mr-2" />
                    Bekor
                  </Button>
                </div>
              </>
            ) : (
              <div className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="bg-gradient-to-br from-orange-50 to-orange-100 p-4 rounded-lg border-2 border-orange-200">
                    <p className="text-sm text-muted-foreground font-semibold">Ism</p>
                    <p className="text-lg font-bold text-foreground">{profile?.name || "Kiritilmagan"}</p>
                  </div>

                  <div className="bg-gradient-to-br from-blue-50 to-blue-100 p-4 rounded-lg border-2 border-blue-200">
                    <p className="text-sm text-muted-foreground font-semibold">Email</p>
                    <p className="text-lg font-bold text-foreground">{profile?.email || "Kiritilmagan"}</p>
                  </div>

                  <div className="bg-gradient-to-br from-green-50 to-green-100 p-4 rounded-lg border-2 border-green-200">
                    <p className="text-sm text-muted-foreground font-semibold">Telefon</p>
                    <p className="text-lg font-bold text-foreground">{profile?.phone || "Kiritilmagan"}</p>
                  </div>

                  <div className="bg-gradient-to-br from-purple-50 to-purple-100 p-4 rounded-lg border-2 border-purple-200">
                    <p className="text-sm text-muted-foreground font-semibold">Manzil</p>
                    <p className="text-lg font-bold text-foreground">{profile?.address || "Kiritilmagan"}</p>
                  </div>
                </div>

                <div className="bg-gradient-to-r from-orange-100 to-blue-100 p-4 rounded-lg border-2 border-orange-300">
                  <p className="text-sm text-muted-foreground font-semibold">Umumiy Balans</p>
                  <p className="text-3xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-orange-600 to-blue-600">
                    {profile?.totalBalance || "0"} so'm
                  </p>
                </div>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Cards Section */}
        <Card className="border-2 border-gray-700 shadow-lg animate-scale-in bg-gray-800/50 backdrop-blur">
          <CardHeader className="bg-gradient-to-r from-blue-900/30 to-purple-900/30 border-b border-gray-700 flex flex-row items-center justify-between">
            <div>
              <CardTitle className="text-2xl text-gray-100">💳 Saqlangan Kartalar</CardTitle>
              <CardDescription className="text-gray-400">Sizning to'lov kartalarini boshqaring</CardDescription>
            </div>
            <Button
              onClick={() => setShowCardModal(true)}
              className="gap-2 bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700"
            >
              <Plus className="w-4 h-4" />
              Karta Qo'shish
            </Button>
          </CardHeader>
          <CardContent className="pt-6">
            {!cards || cards.length === 0 ? (
              <div className="text-center py-12">
                <CreditCard className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                <p className="text-muted-foreground text-lg">Saqlangan kartalar yo'q</p>
                <p className="text-sm text-muted-foreground mt-2">To'lov uchun karta qo'shib boshlang</p>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {cards.map((card, index) => (
                  <div
                    key={card.id}
                    className="service-card border-2 border-gray-600 p-6 rounded-xl bg-gradient-to-br from-gray-700 to-gray-800 hover:shadow-xl smooth-transition"
                    style={{ animationDelay: `${index * 50}ms` }}
                  >
                    <div className="flex justify-between items-start mb-4">
                      <div>
                        <p className="text-sm text-gray-400 font-semibold">Karta Turi</p>
                        <p className="font-bold text-lg capitalize text-gray-100">{card.cardType}</p>
                      </div>
                      {card.isDefault === "yes" && (
                        <span className="bg-green-100 text-green-800 px-3 py-1 rounded-full text-xs font-bold border-2 border-green-300">
                          Asosiy
                        </span>
                      )}
                    </div>

                    <div className="mb-4">
                      <p className="text-sm text-gray-400 font-semibold">Karta Raqami</p>
                      <p className="font-mono text-lg font-bold text-gray-100">{maskCardNumber(card.cardNumber)}</p>
                    </div>

                    <div className="grid grid-cols-2 gap-2 mb-4">
                      <div>
                        <p className="text-xs text-gray-400 font-semibold">Egasi</p>
                        <p className="font-semibold text-gray-100">{card.cardHolder}</p>
                      </div>
                      <div>
                        <p className="text-xs text-gray-400 font-semibold">Muddati</p>
                        <p className="font-semibold text-gray-100">{card.expiryMonth}/{card.expiryYear}</p>
                      </div>
                    </div>

                    <div className="mb-4">
                      <p className="text-sm text-gray-400 font-semibold">Balans</p>
                      <p className="text-2xl font-bold text-green-400">{card.balance} so'm</p>
                    </div>

                    <Button
                      onClick={() => handleDeleteCard(card.id)}
                      variant="destructive"
                      size="sm"
                      className="w-full gap-2"
                    >
                      <Trash2 className="w-4 h-4" />
                      O'chirish
                    </Button>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Add Card Modal */}
      <Dialog open={showCardModal} onOpenChange={setShowCardModal}>
        <DialogContent className="max-w-md animate-scale-in bg-gray-800 border-2 border-gray-700">
          <DialogHeader>
            <DialogTitle className="text-2xl text-gray-100">💳 Yangi Karta Qo'shish</DialogTitle>
          </DialogHeader>

          <div className="space-y-4">
            <div className="space-y-2">
              <Label className="font-semibold">Karta Raqami (16 ta raqam)</Label>
              <Input
                placeholder="1234 5678 9012 3456"
                value={cardData.cardNumber}
                onChange={(e) => {
                  let value = e.target.value.replace(/\s/g, "");
                  if (value.length <= 16) {
                    value = value.replace(/(\d{4})/g, "$1 ").trim();
                    setCardData({ ...cardData, cardNumber: value });
                  }
                }}
                className="border-2 border-gray-600 bg-gray-700 text-gray-100 placeholder-gray-500 focus:border-orange-500 smooth-transition"
              />
            </div>

            <div className="space-y-2">
              <Label className="font-semibold">Karta Egasi</Label>
              <Input
                placeholder="JOHN DOE"
                value={cardData.cardHolder}
                onChange={(e) => setCardData({ ...cardData, cardHolder: e.target.value.toUpperCase() })}
                className="border-2 border-gray-600 bg-gray-700 text-gray-100 placeholder-gray-500 focus:border-orange-500 smooth-transition"
              />
            </div>

            <div className="grid grid-cols-3 gap-2">
              <div className="space-y-2">
                <Label className="font-semibold">Oy</Label>
                <Input
                  type="number"
                  min="1"
                  max="12"
                  placeholder="MM"
                  value={cardData.expiryMonth}
                  onChange={(e) => setCardData({ ...cardData, expiryMonth: e.target.value })}
                  className="border-2 border-gray-600 bg-gray-700 text-gray-100 placeholder-gray-500 focus:border-orange-500 smooth-transition"
                />
              </div>
              <div className="space-y-2">
                <Label className="font-semibold">Yil</Label>
                <Input
                  type="number"
                  min={new Date().getFullYear()}
                  max={new Date().getFullYear() + 20}
                  placeholder="YYYY"
                  value={cardData.expiryYear}
                  onChange={(e) => setCardData({ ...cardData, expiryYear: e.target.value })}
                  className="border-2 border-gray-600 bg-gray-700 text-gray-100 placeholder-gray-500 focus:border-orange-500 smooth-transition"
                />
              </div>
              <div className="space-y-2">
                <Label className="font-semibold">CVV</Label>
                <Input
                  type="password"
                  placeholder="***"
                  maxLength={4}
                  value={cardData.cvv}
                  onChange={(e) => setCardData({ ...cardData, cvv: e.target.value })}
                  className="border-2 border-gray-600 bg-gray-700 text-gray-100 placeholder-gray-500 focus:border-orange-500 smooth-transition"
                />
              </div>
            </div>
          </div>

          <DialogFooter className="flex gap-2">
            <Button
              onClick={() => setShowCardModal(false)}
              variant="outline"
              className="flex-1"
            >
              Bekor
            </Button>
            <Button
              onClick={handleAddCard}
              disabled={createCardMutation.isPending}
              className="flex-1 bg-gradient-to-r from-orange-500 to-blue-600 hover:from-orange-600 hover:to-blue-700 text-white font-bold"
            >
              {createCardMutation.isPending ? "Qo'shilmoqda..." : "Qo'shish"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
