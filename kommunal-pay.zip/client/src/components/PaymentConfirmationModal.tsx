import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { CheckCircle, Printer, Download } from "lucide-react";
import { useRef } from "react";

interface PaymentConfirmationModalProps {
  isOpen: boolean;
  onClose: () => void;
  paymentData?: {
    receiptNumber: string;
    providerName: string;
    accountNumber: string;
    amount: number;
    status: string;
    timestamp: string;
  };
}

export function PaymentConfirmationModal({
  isOpen,
  onClose,
  paymentData,
}: PaymentConfirmationModalProps) {
  const receiptRef = useRef<HTMLDivElement>(null);

  const handlePrint = () => {
    if (receiptRef.current) {
      const printWindow = window.open("", "", "height=500,width=800");
      if (printWindow) {
        printWindow.document.write("<html><head><title>Chek</title>");
        printWindow.document.write(
          "<style>body { font-family: 'Momo Trust Display', sans-serif; padding: 20px; }"
        );
        printWindow.document.write("</style></head><body>");
        printWindow.document.write(receiptRef.current.innerHTML);
        printWindow.document.write("</body></html>");
        printWindow.document.close();
        printWindow.print();
      }
    }
  };

  if (!paymentData) return null;

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-md animate-scale-in">
        <DialogHeader>
          <div className="flex justify-center mb-4">
            <div className="relative">
              <CheckCircle className="w-20 h-20 text-green-500 animate-bounce-soft" />
              <div className="absolute inset-0 animate-pulse-glow"></div>
            </div>
          </div>
          <DialogTitle className="text-center text-3xl font-bold text-green-600">
            To'lov Muvaffaqiyatli! ✓
          </DialogTitle>
          <DialogDescription className="text-center text-lg">
            Sizning to'lovingiz amalga oshirildi
          </DialogDescription>
        </DialogHeader>

        {/* Receipt */}
        <div
          ref={receiptRef}
          className="bg-gradient-to-b from-white to-gray-50 border-2 border-orange-300 rounded-xl p-6 space-y-4 shadow-lg animate-slide-in-down"
        >
          <div className="text-center border-b-2 border-orange-300 pb-4">
            <h3 className="text-2xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-orange-600 to-blue-600">
              KOMMUNAL PAY
            </h3>
            <p className="text-sm text-gray-600 font-semibold">✓ To'lov Cheki</p>
          </div>

          <div className="space-y-3 text-sm">
            <div className="flex justify-between items-center hover:bg-orange-50 p-2 rounded transition-colors duration-200">
              <span className="text-gray-600 font-medium">Chek Raqami:</span>
              <span className="font-bold text-orange-600">{paymentData.receiptNumber}</span>
            </div>

            <div className="flex justify-between items-center hover:bg-blue-50 p-2 rounded transition-colors duration-200">
              <span className="text-gray-600 font-medium">Xizmat Turi:</span>
              <span className="font-bold text-blue-600">{paymentData.providerName}</span>
            </div>

            <div className="flex justify-between items-center hover:bg-gray-100 p-2 rounded transition-colors duration-200">
              <span className="text-gray-600 font-medium">Hisob Raqami:</span>
              <span className="font-mono font-bold">{paymentData.accountNumber}</span>
            </div>

            <div className="border-t-2 border-b-2 border-orange-300 py-3 px-2 bg-gradient-to-r from-orange-50 to-blue-50 rounded">
              <div className="flex justify-between items-center">
                <span className="text-gray-700 font-bold">To'lov Summasi:</span>
                <span className="font-bold text-2xl text-transparent bg-clip-text bg-gradient-to-r from-orange-600 to-blue-600">
                  {(paymentData.amount / 100).toLocaleString("uz-UZ")} so'm
                </span>
              </div>
            </div>

            <div className="flex justify-between items-center hover:bg-gray-100 p-2 rounded transition-colors duration-200">
              <span className="text-gray-600 font-medium">Vaqti:</span>
              <span className="font-semibold text-gray-700">{paymentData.timestamp}</span>
            </div>

            <div className="flex justify-between items-center hover:bg-green-50 p-2 rounded transition-colors duration-200">
              <span className="text-gray-600 font-medium">Holati:</span>
              <span className="font-bold text-green-600 text-lg">✓ {paymentData.status}</span>
            </div>
          </div>

          <div className="border-t-2 border-orange-300 pt-4 text-center text-xs text-gray-600 space-y-1">
            <p className="font-semibold">Raxmat, bizdan foydalanganingiz uchun! 🙏</p>
            <p className="text-orange-600 font-bold">www.kommunalpay.uz</p>
          </div>
        </div>

        <DialogFooter className="flex gap-2 pt-4">
          <Button
            onClick={handlePrint}
            variant="outline"
            className="flex-1 border-2 border-gray-300 hover:border-orange-500 hover:text-orange-600 smooth-transition py-6"
          >
            <Printer className="w-4 h-4 mr-2" />
            Chek Chiqarish
          </Button>
          <Button
            onClick={onClose}
            className="flex-1 payment-button bg-gradient-to-r from-orange-500 to-blue-600 hover:from-orange-600 hover:to-blue-700 text-white font-bold py-6"
          >
            <Download className="w-4 h-4 mr-2" />
            Yopish
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
